import 'package:flutter/foundation.dart';

import '../models/product.dart';

class LocalCartItem {
  final Product product;
  int quantity;

  LocalCartItem({required this.product, this.quantity = 1});

  double get total => product.price * quantity;
}

class AppCartController extends ChangeNotifier {
  AppCartController._();

  static final AppCartController instance = AppCartController._();

  final List<LocalCartItem> _items = [];

  List<LocalCartItem> get items => List.unmodifiable(_items);

  int get totalItems => _items.fold(0, (sum, item) => sum + item.quantity);

  double get subtotal => _items.fold(0, (sum, item) => sum + item.total);

  bool contains(String productId) => _items.any((item) => item.product.id == productId);

  void addProduct(Product product) {
    final index = _items.indexWhere((item) => item.product.id == product.id);
    if (index >= 0) {
      _items[index].quantity += 1;
    } else {
      _items.add(LocalCartItem(product: product));
    }
    notifyListeners();
  }

  void decreaseProduct(String productId) {
    final index = _items.indexWhere((item) => item.product.id == productId);
    if (index < 0) return;
    if (_items[index].quantity > 1) {
      _items[index].quantity -= 1;
    } else {
      _items.removeAt(index);
    }
    notifyListeners();
  }

  void removeProduct(String productId) {
    _items.removeWhere((item) => item.product.id == productId);
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}
