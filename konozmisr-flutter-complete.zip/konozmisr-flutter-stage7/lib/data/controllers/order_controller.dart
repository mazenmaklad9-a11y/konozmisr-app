import 'package:flutter/foundation.dart';

import '../models/order_record.dart';

class OrderController extends ChangeNotifier {
  OrderController._();

  static final OrderController instance = OrderController._();

  final List<OrderRecord> _orders = [];

  List<OrderRecord> get orders => List.unmodifiable(_orders);

  int get totalOrders => _orders.length;

  int get pendingOrders => _orders.where((order) => order.status.contains('بانتظار')).length;

  int get liveOrders => _orders.where((order) => order.isLiveCheckout).length;

  int get onlinePaymentOrders =>
      _orders.where((order) => order.paymentMethod.contains('Shopify')).length;

  int get cashOnDeliveryOrders =>
      _orders.where((order) => order.paymentMethod.contains('الاستلام')).length;

  int get bankTransferOrders =>
      _orders.where((order) => order.paymentMethod.contains('تحويل')).length;

  int get totalTrackedItems =>
      _orders.fold(0, (sum, order) => sum + order.itemSummaries.length);

  double get totalSalesPreview =>
      _orders.fold(0.0, (sum, order) => sum + order.total);

  double get averageOrderValue =>
      _orders.isEmpty ? 0 : totalSalesPreview / _orders.length;

  String get hottestCity {
    if (_orders.isEmpty) return '-';

    final counts = <String, int>{};
    for (final order in _orders) {
      final city = order.city.trim();
      if (city.isEmpty) continue;
      counts[city] = (counts[city] ?? 0) + 1;
    }

    if (counts.isEmpty) return '-';

    final sorted = counts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    return sorted.first.key;
  }

  void addOrder(OrderRecord order) {
    _orders.insert(0, order);
    notifyListeners();
  }

  void clear() {
    _orders.clear();
    notifyListeners();
  }
}
