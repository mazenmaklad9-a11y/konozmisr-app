class Product {
  final String id;
  final String title;
  final String category;
  final String image;
  final double price;
  final double? oldPrice;
  final String description;
  final String compatibility;
  final String? badge;
  final String? variantId;
  final bool isCustomGift;
  final String? orderSummary;

  const Product({
    required this.id,
    required this.title,
    required this.category,
    required this.image,
    required this.price,
    this.oldPrice,
    required this.description,
    this.compatibility = 'مناسب لكل البوكسات',
    this.badge,
    this.variantId,
    this.isCustomGift = false,
    this.orderSummary,
  });

  bool get isSale => oldPrice != null && oldPrice! > price;
}
