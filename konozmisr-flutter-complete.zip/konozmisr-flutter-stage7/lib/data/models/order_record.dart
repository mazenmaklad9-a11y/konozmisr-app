class OrderRecord {
  final String id;
  final String customerName;
  final String phone;
  final String city;
  final String address;
  final String paymentMethod;
  final String status;
  final double total;
  final DateTime createdAt;
  final List<String> itemSummaries;
  final String? checkoutUrl;
  final bool isLiveCheckout;

  const OrderRecord({
    required this.id,
    required this.customerName,
    required this.phone,
    required this.city,
    required this.address,
    required this.paymentMethod,
    required this.status,
    required this.total,
    required this.createdAt,
    required this.itemSummaries,
    this.checkoutUrl,
    this.isLiveCheckout = false,
  });
}
