import 'product.dart';

class GiftBoxOption {
  final String id;
  final String name;
  final String image;
  final double price;
  final String size;
  final String capacity;

  const GiftBoxOption({
    required this.id,
    required this.name,
    required this.image,
    required this.price,
    required this.size,
    required this.capacity,
  });
}

class WrapOption {
  final String id;
  final String title;
  final String description;
  final double price;

  const WrapOption({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
  });
}

class GiftBuilderState {
  final int currentStep;
  final GiftBoxOption? selectedBox;
  final List<Product> selectedProducts;
  final String occasion;
  final String message;
  final String recipientName;
  final String senderName;
  final WrapOption? wrapOption;

  const GiftBuilderState({
    this.currentStep = 0,
    this.selectedBox,
    this.selectedProducts = const [],
    this.occasion = 'عيد ميلاد',
    this.message = '',
    this.recipientName = '',
    this.senderName = '',
    this.wrapOption,
  });

  double get subtotal =>
      (selectedBox?.price ?? 0) +
      selectedProducts.fold(0, (sum, item) => sum + item.price) +
      (wrapOption?.price ?? 0);

  GiftBuilderState copyWith({
    int? currentStep,
    GiftBoxOption? selectedBox,
    List<Product>? selectedProducts,
    String? occasion,
    String? message,
    String? recipientName,
    String? senderName,
    WrapOption? wrapOption,
  }) {
    return GiftBuilderState(
      currentStep: currentStep ?? this.currentStep,
      selectedBox: selectedBox ?? this.selectedBox,
      selectedProducts: selectedProducts ?? this.selectedProducts,
      occasion: occasion ?? this.occasion,
      message: message ?? this.message,
      recipientName: recipientName ?? this.recipientName,
      senderName: senderName ?? this.senderName,
      wrapOption: wrapOption ?? this.wrapOption,
    );
  }
}
