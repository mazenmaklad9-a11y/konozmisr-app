class ShopifyCartLine {
  final String id;
  final String title;
  final String variantId;
  final int quantity;
  final double price;

  const ShopifyCartLine({
    required this.id,
    required this.title,
    required this.variantId,
    required this.quantity,
    required this.price,
  });

  factory ShopifyCartLine.fromJson(Map<String, dynamic> json) {
    final merchandise = (json['merchandise'] as Map<String, dynamic>? ?? {});
    final product = (merchandise['product'] as Map<String, dynamic>? ?? {});
    final price = ((merchandise['price'] as Map<String, dynamic>? ?? {})['amount'] ?? '0').toString();

    return ShopifyCartLine(
      id: (json['id'] ?? '').toString(),
      title: (product['title'] ?? merchandise['title'] ?? 'منتج').toString(),
      variantId: (merchandise['id'] ?? '').toString(),
      quantity: (json['quantity'] ?? 0) as int,
      price: double.tryParse(price) ?? 0,
    );
  }
}

class ShopifyCart {
  final String id;
  final String checkoutUrl;
  final int totalQuantity;
  final double subtotalAmount;
  final List<ShopifyCartLine> lines;

  const ShopifyCart({
    required this.id,
    required this.checkoutUrl,
    required this.totalQuantity,
    required this.subtotalAmount,
    required this.lines,
  });

  factory ShopifyCart.fromJson(Map<String, dynamic> json) {
    final cost = (json['cost'] as Map<String, dynamic>? ?? {});
    final subtotal = ((cost['subtotalAmount'] as Map<String, dynamic>? ?? {})['amount'] ?? '0').toString();
    final lineEdges = ((json['lines'] as Map<String, dynamic>? ?? {})['edges'] as List<dynamic>? ?? const []);

    return ShopifyCart(
      id: (json['id'] ?? '').toString(),
      checkoutUrl: (json['checkoutUrl'] ?? '').toString(),
      totalQuantity: (json['totalQuantity'] ?? 0) as int,
      subtotalAmount: double.tryParse(subtotal) ?? 0,
      lines: lineEdges
          .map((edge) => ShopifyCartLine.fromJson((edge as Map<String, dynamic>)['node'] as Map<String, dynamic>))
          .toList(),
    );
  }
}
