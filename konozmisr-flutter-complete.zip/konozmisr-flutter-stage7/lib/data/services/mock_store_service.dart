import '../models/gift_builder_state.dart';
import '../models/product.dart';

class MockStoreService {
  static const List<String> occasions = [
    'عيد ميلاد',
    'زواج',
    'خطوبة',
    'نجاح',
    'عيد الأم',
    'حج وعمرة',
    'رجالي',
    'نسائي',
  ];

  static const List<String> giftCategories = [
    'شنط',
    'ساعات',
    'كور ثلج',
    'إكسسوارات',
    'ورد',
    'عطور',
    'شوكولاتة',
  ];

  static const List<String> storeCategories = [
    'الكل',
    'بوكسات جاهزة',
    'أطقم القهوة',
    'شنط',
    'ساعات',
    'ورد',
    'إكسسوارات',
    'عطور',
    'شوكولاتة',
  ];

  static const List<String> homeOccasions = [
    'عيد ميلاد',
    'زفاف',
    'خطوبة',
    'رجالي',
    'نسائي',
    'عيد الأم',
  ];

  static const Map<String, List<String>> messageTemplates = {
    'عيد ميلاد': [
      'كل سنة وأنت بخير وسعادة وفرحة لا تنتهي.',
      'عيد ميلاد سعيد وأيامك كلها هدايا جميلة.',
      'هدية صغيرة تحمل لك محبة كبيرة.',
    ],
    'زواج': [
      'ألف مبروك وبداية سعيدة مليئة بالحب والهناء.',
      'بارك الله لكما وبارك عليكما وجمع بينكما في خير.',
      'هدية تليق بفرحتكما الجميلة.',
    ],
    'خطوبة': [
      'أجمل التهاني بمناسبة الخطوبة وعقبال الزفاف.',
      'فرحة اليوم بداية لأيام أجمل بإذن الله.',
      'هدية من القلب لمناسبة تستحق الفخامة.',
    ],
    'نجاح': [
      'مبروك النجاح وعقبال أعلى المراتب.',
      'تستحق هذه الفرحة وأكثر، مبارك عليك النجاح.',
      'هذه الهدية احتفالاً بإنجازك الرائع.',
    ],
    'عيد الأم': [
      'إلى أمي الغالية، كل الحب والامتنان في هذه الهدية.',
      'أنتِ الهدية الأجمل في حياتنا، عيد أم سعيد.',
      'شكراً لكل حبك وحنانك وعطائك.',
    ],
    'حج وعمرة': [
      'تقبل الله طاعتكم وكتب لكم الأجر والقبول.',
      'عمرة مقبولة وذنب مغفور بإذن الله.',
      'هدية مباركة لمناسبة روحانية جميلة.',
    ],
    'رجالي': [
      'هدية تليق بذوقك وأناقتك.',
      'تقديراً لشخصك المميز، اخترنا لك هذه الهدية.',
    ],
    'نسائي': [
      'هدية أنيقة تحمل لك أجمل المشاعر.',
      'لفتة راقية لشخصية تستحق كل الجمال.',
    ],
  };

  static const Map<String, double> addonPrices = {
    'شريط ساتان': 25,
    'ختم شمع': 30,
    'بطاقة مطبوعة': 20,
    'اسم على التغليف': 15,
    'وردة إضافية': 45,
    'شنطة فاخرة': 60,
  };

  static const List<GiftBoxOption> boxes = [
    GiftBoxOption(
      id: 'b1',
      name: 'البوكس الملكي',
      image: '🎁',
      price: 320,
      size: 'كبير',
      capacity: '5 - 7 قطع',
    ),
    GiftBoxOption(
      id: 'b2',
      name: 'بوكس المخمل',
      image: '👜',
      price: 250,
      size: 'متوسط',
      capacity: '3 - 5 قطع',
    ),
    GiftBoxOption(
      id: 'b3',
      name: 'بوكس المناسبات',
      image: '💝',
      price: 280,
      size: 'متوسط',
      capacity: '4 - 6 قطع',
    ),
    GiftBoxOption(
      id: 'b4',
      name: 'بوكس ورد وذهب',
      image: '🌹',
      price: 360,
      size: 'كبير',
      capacity: '6 - 8 قطع',
    ),
  ];

  static const List<WrapOption> wraps = [
    WrapOption(
      id: 'w1',
      title: 'تغليف كلاسيك',
      description: 'تغليف أنيق وهادئ مناسب لكل المناسبات',
      price: 60,
    ),
    WrapOption(
      id: 'w2',
      title: 'تغليف فاخر',
      description: 'ورق فاخر وشريط ساتان ولمسة ذهبية',
      price: 120,
    ),
    WrapOption(
      id: 'w3',
      title: 'تغليف ورد',
      description: 'لمسات ورد وتغليف مميز للمناسبات الرومانسية',
      price: 150,
    ),
    WrapOption(
      id: 'w4',
      title: 'تغليف ملكي',
      description: 'تنسيق خاص للمناسبات الفاخرة والهدايا الرسمية',
      price: 180,
    ),
  ];

  static const List<Product> products = [
    Product(
      id: 'p1',
      title: 'شنطة قمر الصحراء',
      category: 'شنط',
      image: '👜',
      price: 890,
      oldPrice: 990,
      description: 'شنطة أنيقة بتفاصيل ذهبية ولمسة أنثوية فاخرة تناسب هدايا المناسبات الراقية.',
      compatibility: 'مناسب للبوكس الكبير والمتوسط',
      badge: 'الأكثر طلبًا',
    ),
    Product(
      id: 'p2',
      title: 'ساعة أناقة الذهب',
      category: 'ساعات',
      image: '⌚',
      price: 640,
      oldPrice: 720,
      description: 'ساعة راقية بمظهر كلاسيكي عصري تضيف قيمة مميزة داخل البوكس.',
      compatibility: 'مناسب للبوكس المتوسط',
      badge: 'هدية رجالية',
    ),
    Product(
      id: 'p3',
      title: 'وردة محفوظة فاخرة',
      category: 'ورد',
      image: '🌹',
      price: 220,
      description: 'وردة محفوظة بستايل فاخر تضيف لمسة رومانسية جميلة للهدية.',
      compatibility: 'مناسب لكل البوكسات',
    ),
    Product(
      id: 'p4',
      title: 'عطر لمسة المساء',
      category: 'عطور',
      image: '🧴',
      price: 520,
      description: 'عطر أنيق بنفحات دافئة مناسب للهدايا النسائية والراقية.',
      compatibility: 'مناسب للبوكس المتوسط والكبير',
      badge: 'مميز',
    ),
    Product(
      id: 'p5',
      title: 'إكسسوار لمعة راقية',
      category: 'إكسسوارات',
      image: '💍',
      price: 340,
      description: 'قطعة إكسسوار ناعمة مناسبة للهدايا السريعة والبسيطة الفاخرة.',
      compatibility: 'مناسب لكل البوكسات',
    ),
    Product(
      id: 'p6',
      title: 'شوكولاتة هدية فاخرة',
      category: 'شوكولاتة',
      image: '🍫',
      price: 190,
      description: 'علبة شوكولاتة مختارة بعناية تضيف ذوقاً راقياً للهدية.',
      compatibility: 'مناسب لكل البوكسات',
      badge: 'إضافة مثالية',
    ),
    Product(
      id: 'p7',
      title: 'كور ثلج ستيل فاخرة',
      category: 'كور ثلج',
      image: '🧊',
      price: 260,
      description: 'إضافة رجالية أنيقة تناسب هدايا الضيافة والمناسبات الخاصة.',
      compatibility: 'مناسب للبوكس المتوسط والكبير',
    ),
    Product(
      id: 'p8',
      title: 'بوكس ليلة زفاف',
      category: 'بوكسات جاهزة',
      image: '💒',
      price: 1690,
      oldPrice: 1890,
      description: 'بوكس جاهز فاخر للزفاف بتنسيق أنيق ولمسات ذهبية فخمة.',
      compatibility: 'جاهز للطلب المباشر',
      badge: 'زواج',
    ),
    Product(
      id: 'p9',
      title: 'بوكس عيد ميلاد فاخر',
      category: 'بوكسات جاهزة',
      image: '🎂',
      price: 1240,
      oldPrice: 1390,
      description: 'بوكس جاهز لعيد الميلاد بتغليف فاخر ورسالة تهنئة مميزة.',
      compatibility: 'جاهز للطلب المباشر',
      badge: 'عيد ميلاد',
    ),
    Product(
      id: 'p10',
      title: 'طقم الضيافة الملكية',
      category: 'أطقم القهوة',
      image: '☕',
      price: 1794,
      oldPrice: 1994,
      description: 'طقم ضيافة مستوحى من الذوق الشرقي الفاخر يليق بالهدايا المميزة.',
      compatibility: 'منتج مستقل',
      badge: 'طقم قهوة',
    ),
    Product(
      id: 'p11',
      title: 'فناجين القهوة السلطانة',
      category: 'أطقم القهوة',
      image: '🍶',
      price: 994,
      oldPrice: 1194,
      description: 'فناجين قهوة بطابع ملكي راقٍ مستوحاة من التراث المصري الأصيل.',
      compatibility: 'منتج مستقل',
      badge: 'عرض',
    ),
    Product(
      id: 'p12',
      title: 'بوكس عيد الأم الماسي',
      category: 'بوكسات جاهزة',
      image: '🌷',
      price: 1490,
      description: 'بوكس جاهز لعيد الأم يتضمن تنسيقاً ناعماً وكلمات تقدير دافئة.',
      compatibility: 'جاهز للطلب المباشر',
      badge: 'عيد الأم',
    ),
  ];

  static List<Product> get featuredProducts => products.take(4).toList();

  static List<Product> get readyBoxes =>
      products.where((product) => product.category == 'بوكسات جاهزة').toList();

  static List<Product> get coffeeSets =>
      products.where((product) => product.category == 'أطقم القهوة').toList();

  static List<Product> get offers =>
      products.where((product) => product.isSale).toList();

  static List<Product> get builderProducts =>
      products.where((product) => giftCategories.contains(product.category)).toList();
}
