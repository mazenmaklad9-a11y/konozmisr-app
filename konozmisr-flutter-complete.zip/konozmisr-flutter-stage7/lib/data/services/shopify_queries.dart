class ShopifyQueries {
  static String productsByCollectionHandle(String handle) => '''
query ProductsByCollectionHandle {
  collectionByHandle(handle: "$handle") {
    id
    title
    handle
    products(first: 40) {
      edges {
        node {
          id
          title
          description
          productType
          tags
          featuredImage {
            url
          }
          variants(first: 1) {
            edges {
              node {
                id
                title
                price {
                  amount
                  currencyCode
                }
                compareAtPrice {
                  amount
                }
              }
            }
          }
        }
      }
    }
  }
}
''';

  static String allProducts() => '''
query AllProducts {
  products(first: 60, sortKey: CREATED_AT, reverse: true) {
    edges {
      node {
        id
        title
        description
        productType
        tags
        featuredImage {
          url
        }
        variants(first: 1) {
          edges {
            node {
              id
              title
              price {
                amount
                currencyCode
              }
              compareAtPrice {
                amount
              }
            }
          }
        }
      }
    }
  }
}
''';

  static String cartCreate(List<Map<String, dynamic>> lines) {
    final lineInputs = lines
        .map((line) => '''
        {
          merchandiseId: "${line['merchandiseId']}"
          quantity: ${line['quantity']}
        }
        ''')
        .join(',');

    return '''
mutation CartCreate {
  cartCreate(
    input: {
      lines: [
        $lineInputs
      ]
    }
  ) {
    cart {
      id
      checkoutUrl
      totalQuantity
      cost {
        subtotalAmount {
          amount
          currencyCode
        }
      }
      lines(first: 50) {
        edges {
          node {
            id
            quantity
            merchandise {
              ... on ProductVariant {
                id
                title
                price {
                  amount
                  currencyCode
                }
                product {
                  title
                }
              }
            }
          }
        }
      }
    }
    userErrors {
      field
      message
    }
  }
}
''';
  }

  static String cartLinesAdd({
    required String cartId,
    required String merchandiseId,
    int quantity = 1,
  }) => '''
mutation CartLinesAdd {
  cartLinesAdd(
    cartId: "$cartId"
    lines: [
      {
        merchandiseId: "$merchandiseId"
        quantity: $quantity
      }
    ]
  ) {
    cart {
      id
      checkoutUrl
      totalQuantity
      cost {
        subtotalAmount {
          amount
          currencyCode
        }
      }
      lines(first: 50) {
        edges {
          node {
            id
            quantity
            merchandise {
              ... on ProductVariant {
                id
                title
                price {
                  amount
                  currencyCode
                }
                product {
                  title
                }
              }
            }
          }
        }
      }
    }
    userErrors {
      field
      message
    }
  }
}
''';

  static String cartBuyerIdentityUpdate({
    required String cartId,
    required String email,
    String? phone,
    String countryCode = 'EG',
  }) => '''
mutation CartBuyerIdentityUpdate {
  cartBuyerIdentityUpdate(
    cartId: "$cartId"
    buyerIdentity: {
      email: "$email"
      ${phone != null && phone.isNotEmpty ? 'phone: "$phone"' : ''}
      countryCode: $countryCode
    }
  ) {
    cart {
      id
      checkoutUrl
      totalQuantity
      cost {
        subtotalAmount {
          amount
          currencyCode
        }
      }
      buyerIdentity {
        email
        phone
        countryCode
      }
    }
    userErrors {
      field
      message
    }
  }
}
''';

  static String cartById(String cartId) => '''
query CartById {
  cart(id: "$cartId") {
    id
    checkoutUrl
    totalQuantity
    cost {
      subtotalAmount {
        amount
        currencyCode
      }
    }
    lines(first: 50) {
      edges {
        node {
          id
          quantity
          merchandise {
            ... on ProductVariant {
              id
              title
              price {
                amount
                currencyCode
              }
              product {
                title
              }
            }
          }
        }
      }
    }
  }
}
''';
}
