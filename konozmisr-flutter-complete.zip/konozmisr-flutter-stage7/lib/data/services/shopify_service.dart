import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../core/config/app_config.dart';
import '../models/product.dart';
import '../models/shopify_cart.dart';
import 'shopify_queries.dart';

class ShopifyService {
  final http.Client client;

  ShopifyService({http.Client? client}) : client = client ?? http.Client();

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'X-Shopify-Storefront-Access-Token': AppConfig.publicStorefrontToken,
      };

  Future<Map<String, dynamic>> storefrontQuery(String query) async {
    if (!AppConfig.hasValidStorefrontToken) {
      throw Exception('يرجى إضافة Public Storefront Token أولاً داخل AppConfig.');
    }

    final response = await client.post(
      Uri.parse(AppConfig.storefrontGraphQLEndpoint),
      headers: _headers,
      body: jsonEncode({'query': query}),
    );

    if (response.statusCode >= 400) {
      throw Exception('Shopify request failed: ${response.statusCode}');
    }

    final decoded = jsonDecode(response.body) as Map<String, dynamic>;

    if (decoded['errors'] != null) {
      throw Exception(decoded['errors'].toString());
    }

    return decoded;
  }

  Future<List<Product>> fetchAllProducts() async {
    final data = await storefrontQuery(ShopifyQueries.allProducts());
    final edges = ((((data['data'] ?? {})['products'] ?? {})['edges']) as List<dynamic>? ?? const []);
    return _mapProductsFromEdges(edges);
  }

  Future<List<Product>> fetchCollectionProducts({
    required String handle,
    required String fallbackCategory,
  }) async {
    final data = await storefrontQuery(ShopifyQueries.productsByCollectionHandle(handle));
    final collection = (((data['data'] ?? {})['collectionByHandle']) ?? {}) as Map<String, dynamic>;
    final edges = (((collection['products'] ?? {})['edges']) as List<dynamic>? ?? const []);
    return _mapProductsFromEdges(edges, forcedCategory: fallbackCategory);
  }

  Future<ShopifyCart> createCart({
    required List<Map<String, dynamic>> lines,
  }) async {
    final response = await storefrontQuery(ShopifyQueries.cartCreate(lines));
    final payload = ((response['data'] ?? {})['cartCreate'] ?? {}) as Map<String, dynamic>;
    _throwUserErrors(payload);
    return ShopifyCart.fromJson((payload['cart'] ?? {}) as Map<String, dynamic>);
  }

  Future<ShopifyCart> addCartLine({
    required String cartId,
    required String merchandiseId,
    int quantity = 1,
  }) async {
    final response = await storefrontQuery(
      ShopifyQueries.cartLinesAdd(
        cartId: cartId,
        merchandiseId: merchandiseId,
        quantity: quantity,
      ),
    );

    final payload = ((response['data'] ?? {})['cartLinesAdd'] ?? {}) as Map<String, dynamic>;
    _throwUserErrors(payload);
    return ShopifyCart.fromJson((payload['cart'] ?? {}) as Map<String, dynamic>);
  }

  Future<ShopifyCart> updateBuyerIdentity({
    required String cartId,
    required String email,
    String? phone,
    String countryCode = 'EG',
  }) async {
    final response = await storefrontQuery(
      ShopifyQueries.cartBuyerIdentityUpdate(
        cartId: cartId,
        email: email,
        phone: phone,
        countryCode: countryCode,
      ),
    );

    final payload = ((response['data'] ?? {})['cartBuyerIdentityUpdate'] ?? {}) as Map<String, dynamic>;
    _throwUserErrors(payload);
    return ShopifyCart.fromJson((payload['cart'] ?? {}) as Map<String, dynamic>);
  }

  Future<ShopifyCart> fetchCart(String cartId) async {
    final response = await storefrontQuery(ShopifyQueries.cartById(cartId));
    final cartData = ((response['data'] ?? {})['cart'] ?? {}) as Map<String, dynamic>;
    return ShopifyCart.fromJson(cartData);
  }

  Future<String> fetchCheckoutUrl(String cartId) async {
    final cart = await fetchCart(cartId);
    return cart.checkoutUrl;
  }

  List<Product> _mapProductsFromEdges(
    List<dynamic> edges, {
    String? forcedCategory,
  }) {
    return edges.map((edge) {
      final node = (edge as Map<String, dynamic>)['node'] as Map<String, dynamic>;
      final imageUrl = ((node['featuredImage'] ?? {})['url'] ?? '').toString();
      final variants = (((node['variants'] ?? {})['edges']) as List<dynamic>? ?? const []);
      final firstVariant = variants.isEmpty
          ? <String, dynamic>{}
          : ((variants.first as Map<String, dynamic>)['node'] as Map<String, dynamic>);
      final price = (((firstVariant['price'] ?? {})['amount']) ?? '0').toString();
      final compare = (((firstVariant['compareAtPrice'] ?? {})['amount']) ?? '').toString();
      final title = (node['title'] ?? '').toString();
      final description = (node['description'] ?? '').toString();
      final productType = (node['productType'] ?? '').toString();
      final tags = ((node['tags'] as List<dynamic>? ?? const [])).map((e) => e.toString()).toList();

      return Product(
        id: (node['id'] ?? '').toString(),
        title: title,
        category: forcedCategory ?? _inferCategory(title, description, productType, tags),
        image: imageUrl.isEmpty ? '🛍️' : imageUrl,
        price: double.tryParse(price) ?? 0,
        oldPrice: compare.isEmpty ? null : double.tryParse(compare),
        description: description.isEmpty ? 'منتج مرتبط مباشرة بمتجر Shopify.' : description,
        compatibility: 'مربوط بمتجرك عبر Shopify',
        badge: 'مباشر من المتجر',
        variantId: (firstVariant['id'] ?? '').toString().isEmpty ? null : (firstVariant['id'] ?? '').toString(),
      );
    }).toList();
  }

  String _inferCategory(
    String title,
    String description,
    String productType,
    List<String> tags,
  ) {
    final haystack = '${title.toLowerCase()} ${description.toLowerCase()} ${productType.toLowerCase()} ${tags.join(' ').toLowerCase()}';

    if (_containsAny(haystack, ['قهوة', 'فنجان', 'فناجين', 'ضيافة', 'دلة', 'coffee', 'cup'])) {
      return 'أطقم القهوة';
    }
    if (_containsAny(haystack, ['بوكس', 'box', 'هدية جاهزة', 'زفاف', 'خطوبة', 'عيد ميلاد'])) {
      return 'بوكسات جاهزة';
    }
    if (_containsAny(haystack, ['شنطة', 'شنط', 'bag', 'handbag'])) {
      return 'شنط';
    }
    if (_containsAny(haystack, ['ساعة', 'watch'])) {
      return 'ساعات';
    }
    if (_containsAny(haystack, ['ورد', 'rose', 'flower'])) {
      return 'ورد';
    }
    if (_containsAny(haystack, ['عطر', 'perfume', 'fragrance'])) {
      return 'عطور';
    }
    if (_containsAny(haystack, ['شوكولات', 'chocolate'])) {
      return 'شوكولاتة';
    }
    if (_containsAny(haystack, ['اكسسوار', 'إكسسوارات', 'accessory', 'jewelry'])) {
      return 'إكسسوارات';
    }
    if (_containsAny(haystack, ['ثلج', 'ice'])) {
      return 'كور ثلج';
    }
    return 'متجر كنوز مصر';
  }

  bool _containsAny(String text, List<String> terms) {
    for (final term in terms) {
      if (text.contains(term.toLowerCase())) return true;
    }
    return false;
  }

  void _throwUserErrors(Map<String, dynamic> payload) {
    final errors = (payload['userErrors'] as List<dynamic>? ?? const []);
    if (errors.isNotEmpty) {
      final messages = errors
          .map((e) => (e as Map<String, dynamic>)['message']?.toString() ?? 'Unknown Shopify error')
          .join(' | ');
      throw Exception(messages);
    }
  }
}
