import '../../core/config/app_config.dart';
import '../models/product.dart';
import '../services/mock_store_service.dart';
import '../services/shopify_service.dart';

class HomeSectionsData {
  final List<Product> featured;
  final List<Product> readyBoxes;
  final List<Product> coffeeSets;
  final List<Product> offers;
  final bool isLive;

  const HomeSectionsData({
    required this.featured,
    required this.readyBoxes,
    required this.coffeeSets,
    required this.offers,
    required this.isLive,
  });
}

class StoreRepository {
  StoreRepository({ShopifyService? shopifyService})
      : _shopifyService = shopifyService ?? ShopifyService();

  final ShopifyService _shopifyService;

  Future<List<Product>> getCatalogProducts() async {
    final remote = await _loadRemoteProducts();
    return remote ?? MockStoreService.products;
  }

  Future<List<Product>> getGiftBuilderProducts() async {
    final remote = await _loadRemoteProducts();
    final builder = (remote ?? MockStoreService.products)
        .where((product) => MockStoreService.giftCategories.contains(product.category))
        .toList();
    return builder.isEmpty ? MockStoreService.builderProducts : builder;
  }

  Future<HomeSectionsData> getHomeSections() async {
    final remote = await _loadRemoteProducts();
    final source = remote ?? MockStoreService.products;
    return HomeSectionsData(
      featured: source.take(4).toList(),
      readyBoxes: _filterByCategory(source, 'بوكسات جاهزة', fallback: MockStoreService.readyBoxes),
      coffeeSets: _filterByCategory(source, 'أطقم القهوة', fallback: MockStoreService.coffeeSets),
      offers: source.where((product) => product.isSale).take(6).toList(),
      isLive: remote != null,
    );
  }

  Future<List<Product>?> _loadRemoteProducts() async {
    if (!AppConfig.hasValidStorefrontToken || AppConfig.enableMockData) {
      return null;
    }

    try {
      final products = await _shopifyService.fetchAllProducts();
      if (products.isEmpty) return null;
      return products;
    } catch (_) {
      return null;
    }
  }

  List<Product> _filterByCategory(
    List<Product> products,
    String category, {
    required List<Product> fallback,
  }) {
    final filtered = products.where((product) => product.category == category).toList();
    return filtered.isEmpty ? fallback : filtered;
  }
}
