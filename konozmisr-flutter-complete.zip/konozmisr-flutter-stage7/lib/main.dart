import 'package:flutter/material.dart';

import 'core/theme/app_theme.dart';
import 'presentation/screens/account/account_screen.dart';
import 'presentation/screens/cart/cart_screen.dart';
import 'presentation/screens/catalog/catalog_screen.dart';
import 'presentation/screens/gift_builder/gift_builder_screen.dart';
import 'presentation/screens/home/home_screen.dart';
import 'presentation/widgets/app_bottom_nav.dart';

void main() {
  runApp(const KonozMisrApp());
}

class KonozMisrApp extends StatelessWidget {
  const KonozMisrApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Konoz Misr',
      theme: AppTheme.lightTheme,
      home: const AppShell(),
    );
  }
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int currentIndex = 0;

  void _goToTab(int index) {
    setState(() => currentIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(onNavigateToTab: _goToTab),
      GiftBuilderScreen(onNavigateToCart: () => _goToTab(3)),
      const CatalogScreen(),
      const CartScreen(),
      const AccountScreen(),
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(index: currentIndex, children: pages),
        bottomNavigationBar: AppBottomNav(
          currentIndex: currentIndex,
          onTap: _goToTab,
        ),
      ),
    );
  }
}
