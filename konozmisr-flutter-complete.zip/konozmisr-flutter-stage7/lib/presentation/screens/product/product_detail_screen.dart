import 'package:flutter/material.dart';

import '../../../core/config/app_config.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/controllers/app_cart_controller.dart';
import '../../../data/models/product.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;
  final VoidCallback? onAddToCart;

  const ProductDetailScreen({
    super.key,
    required this.product,
    this.onAddToCart,
  });

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  int quantity = 1;

  bool get _hasNetworkImage => widget.product.image.startsWith('http');

  @override
  Widget build(BuildContext context) {
    final product = widget.product;
    final total = product.price * quantity;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: AppColors.ivory,
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              pinned: true,
              backgroundColor: AppColors.ivory,
              foregroundColor: AppColors.textPrimary,
              title: const Text('تفاصيل المنتج'),
              actions: const [
                Padding(
                  padding: EdgeInsetsDirectional.only(end: 12),
                  child: Icon(Icons.favorite_border_rounded),
                ),
              ],
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 120),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(28),
                      decoration: BoxDecoration(
                        color: AppColors.card,
                        borderRadius: BorderRadius.circular(30),
                        border: Border.all(color: AppColors.line),
                      ),
                      child: Column(
                        children: [
                          Align(
                            alignment: AlignmentDirectional.topStart,
                            child: Row(
                              children: [
                                if (product.badge != null)
                                  _Badge(label: product.badge!, color: AppColors.gold, textColor: AppColors.mocha),
                                if (product.isSale) ...[
                                  const SizedBox(width: 8),
                                  const _Badge(label: 'خصم', color: AppColors.rose, textColor: Colors.white),
                                ],
                                if (product.variantId != null) ...[
                                  const SizedBox(width: 8),
                                  const _Badge(label: 'Shopify', color: AppColors.teal, textColor: Colors.white),
                                ],
                              ],
                            ),
                          ),
                          const SizedBox(height: 20),
                          _hasNetworkImage
                              ? ClipRRect(
                                  borderRadius: BorderRadius.circular(24),
                                  child: Image.network(
                                    product.image,
                                    height: 240,
                                    width: double.infinity,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) => const Text('🛍️', style: TextStyle(fontSize: 92)),
                                  ),
                                )
                              : Text(product.image, style: const TextStyle(fontSize: 92)),
                          const SizedBox(height: 20),
                          Text(
                            product.title,
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                              fontSize: 26,
                              fontWeight: FontWeight.w800,
                              color: AppColors.textPrimary,
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            product.category,
                            style: const TextStyle(
                              color: AppColors.textMuted,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        Text(
                          '${product.price.toStringAsFixed(0)} ج.م',
                          style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.w900,
                            color: AppColors.mocha,
                          ),
                        ),
                        const SizedBox(width: 10),
                        if (product.oldPrice != null)
                          Text(
                            '${product.oldPrice!.toStringAsFixed(0)} ج.م',
                            style: const TextStyle(
                              decoration: TextDecoration.lineThrough,
                              color: AppColors.textMuted,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Text(
                      product.description,
                      style: const TextStyle(
                        color: AppColors.textSecondary,
                        height: 1.7,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 18),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: product.variantId != null ? const Color(0xFFEAF4E4) : const Color(0xFFFFF7F1),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(
                          color: product.variantId != null ? const Color(0xFFCFE5C7) : AppColors.line,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                product.variantId != null ? Icons.cloud_done_rounded : Icons.science_outlined,
                                color: product.variantId != null ? AppColors.olive : AppColors.warning,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                product.variantId != null ? 'جاهز للدفع المباشر' : 'وضع اختبار / Mock',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: product.variantId != null ? AppColors.olive : AppColors.mocha,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Text(
                            product.variantId != null
                                ? 'المنتج ده يقدر يدخل مباشرة في Shopify Checkout لما الـ token يكون جاهز، وده يسرّع الإطلاق ويزود معدل التحويل.'
                                : 'المنتج ده مناسب جدًا للاختبار وتجربة الرحلة، لكن لفتح Checkout حي محتاج Variant ID وربط مباشر.',
                            style: const TextStyle(height: 1.7),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'وضع البيانات الحالي: ${AppConfig.dataModeLabel}',
                            style: const TextStyle(
                              color: AppColors.textMuted,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'مناسب داخل بوكس الهدية',
                              style: TextStyle(
                                color: AppColors.mocha,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              product.compatibility,
                              style: const TextStyle(color: AppColors.teal, height: 1.6),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Row(
                          children: [
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'الكمية',
                                    style: TextStyle(
                                      color: AppColors.mocha,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  ),
                                  SizedBox(height: 6),
                                  Text('يمكنك تعديل الكمية قبل الإضافة إلى العربة'),
                                ],
                              ),
                            ),
                            _QuantityButton(
                              icon: Icons.add,
                              onTap: () => setState(() => quantity++),
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 14),
                              child: Text(
                                '$quantity',
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                            _QuantityButton(
                              icon: Icons.remove,
                              onTap: () {
                                if (quantity > 1) {
                                  setState(() => quantity--);
                                }
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFF7F1),
                        borderRadius: BorderRadius.circular(24),
                        border: Border.all(color: AppColors.line),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'لماذا هذا المنتج؟',
                            style: TextStyle(
                              color: AppColors.mocha,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 10),
                          const _FeatureRow(text: 'تصميم راقٍ مناسب للهدايا الفاخرة'),
                          const _FeatureRow(text: 'مظهر احترافي داخل تطبيق كنوز مصر'),
                          Text(
                            product.variantId != null
                                ? 'هذا المنتج جاهز تقنيًا للربط بعربة Shopify المباشرة.'
                                : 'هذا المنتج يعمل حاليًا داخل وضع التجربة أو البيانات المحلية.',
                            style: const TextStyle(height: 1.7),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        bottomSheet: Container(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
          decoration: const BoxDecoration(
            color: AppColors.card,
            border: Border(top: BorderSide(color: AppColors.line)),
          ),
          child: SafeArea(
            top: false,
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'إجمالي المنتج',
                        style: TextStyle(
                          color: AppColors.textMuted,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${total.toStringAsFixed(0)} ج.م',
                        style: const TextStyle(
                          color: AppColors.mocha,
                          fontSize: 22,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      for (var i = 0; i < quantity; i++) {
                        AppCartController.instance.addProduct(product);
                      }
                      widget.onAddToCart?.call();
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          backgroundColor: AppColors.olive,
                          content: Text('تمت إضافة ${product.title} إلى العربة'),
                        ),
                      );
                    },
                    icon: const Icon(Icons.shopping_bag_outlined),
                    label: const Text('أضف للعربة'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Badge extends StatelessWidget {
  final String label;
  final Color color;
  final Color textColor;

  const _Badge({
    required this.label,
    required this.color,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 12,
        ),
      ),
    );
  }
}

class _QuantityButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _QuantityButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: AppColors.beige,
          borderRadius: BorderRadius.circular(14),
        ),
        child: Icon(icon, color: AppColors.mocha, size: 20),
      ),
    );
  }
}

class _FeatureRow extends StatelessWidget {
  final String text;
  const _FeatureRow({required this.text});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 4),
            child: Icon(Icons.check_circle, color: AppColors.gold, size: 18),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(height: 1.6),
            ),
          ),
        ],
      ),
    );
  }
}
