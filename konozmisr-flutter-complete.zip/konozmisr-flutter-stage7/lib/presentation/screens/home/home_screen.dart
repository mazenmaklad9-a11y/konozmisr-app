import 'package:flutter/material.dart';

import '../../../core/config/app_config.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/controllers/app_cart_controller.dart';
import '../../../data/models/product.dart';
import '../../../data/repositories/store_repository.dart';
import '../../../data/services/mock_store_service.dart';
import '../../widgets/product_card.dart';
import '../../widgets/section_header.dart';
import '../product/product_detail_screen.dart';

class HomeScreen extends StatefulWidget {
  final ValueChanged<int> onNavigateToTab;

  const HomeScreen({
    super.key,
    required this.onNavigateToTab,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final StoreRepository _repository = StoreRepository();
  late Future<HomeSectionsData> _future;

  @override
  void initState() {
    super.initState();
    _future = _repository.getHomeSections();
  }

  void _reload() {
    setState(() => _future = _repository.getHomeSections());
  }

  void _openProduct(Product product) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product)),
    );
  }

  void _addToCart(Product product) {
    AppCartController.instance.addProduct(product);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.olive,
        content: Text('تمت إضافة ${product.title} إلى العربة'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: FutureBuilder<HomeSectionsData>(
        future: _future,
        builder: (context, snapshot) {
          final loading = snapshot.connectionState == ConnectionState.waiting;
          final data = snapshot.data;

          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 54,
                            height: 54,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(
                                colors: [Color(0xFFC97A68), Color(0xFF2E6D66)],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: const Center(
                              child: Text(
                                'KM',
                                style: TextStyle(
                                  fontWeight: FontWeight.w900,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('كنوز مصر', style: Theme.of(context).textTheme.titleLarge),
                                const SizedBox(height: 3),
                                const Text(
                                  'هدايا راقية لكل مناسبة',
                                  style: TextStyle(color: AppColors.textMuted),
                                ),
                              ],
                            ),
                          ),
                          _CircleIconButton(icon: Icons.search_rounded, onTap: () => widget.onNavigateToTab(2)),
                          const SizedBox(width: 8),
                          AnimatedBuilder(
                            animation: AppCartController.instance,
                            builder: (context, _) {
                              return Stack(
                                children: [
                                  _CircleIconButton(
                                    icon: Icons.shopping_bag_outlined,
                                    onTap: () => widget.onNavigateToTab(3),
                                  ),
                                  if (AppCartController.instance.totalItems > 0)
                                    Positioned(
                                      top: 0,
                                      left: 0,
                                      child: Container(
                                        width: 18,
                                        height: 18,
                                        decoration: const BoxDecoration(
                                          color: AppColors.rose,
                                          shape: BoxShape.circle,
                                        ),
                                        child: Center(
                                          child: Text(
                                            '${AppCartController.instance.totalItems}',
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 10,
                                              fontWeight: FontWeight.w800,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              );
                            },
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _LiveStatusBanner(
                        isLive: data?.isLive == true,
                        onRefresh: _reload,
                      ),
                      const SizedBox(height: 18),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(22),
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [AppColors.mocha, Color(0xFF6A4B3A)],
                            begin: Alignment.topRight,
                            end: Alignment.bottomLeft,
                          ),
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.12),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                data?.isLive == true ? 'بيانات مباشرة من المتجر' : 'تجربة تسوق فاخرة',
                                style: const TextStyle(
                                  color: Color(0xFFF8E8D1),
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                            const SizedBox(height: 16),
                            const Text(
                              'الفخامة تبدأ من هنا ✨',
                              style: TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.w900,
                                color: Colors.white,
                                height: 1.2,
                              ),
                            ),
                            const SizedBox(height: 10),
                            const Text(
                              'بوكسات هدايا وأطقم قهوة وتنسيقات راقية تناسب الزفاف والخطوبة وأعياد الميلاد وكل المناسبات.',
                              style: TextStyle(
                                color: Color(0xFFF8E8D1),
                                height: 1.6,
                                fontSize: 15,
                              ),
                            ),
                            const SizedBox(height: 18),
                            Row(
                              children: [
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: () => widget.onNavigateToTab(1),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: AppColors.gold,
                                      foregroundColor: AppColors.textPrimary,
                                    ),
                                    child: const Text('ابدأ هديتك الآن'),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: OutlinedButton(
                                    onPressed: () => widget.onNavigateToTab(2),
                                    style: OutlinedButton.styleFrom(
                                      foregroundColor: Colors.white,
                                      side: const BorderSide(color: Color(0xFFF8E8D1)),
                                    ),
                                    child: const Text('تسوق الأقسام'),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: const [
                          _TrustChip(icon: Icons.local_shipping_outlined, label: 'شحن سريع'),
                          SizedBox(width: 8),
                          _TrustChip(icon: Icons.inventory_2_outlined, label: 'تغليف فاخر'),
                          SizedBox(width: 8),
                          _TrustChip(icon: Icons.payments_outlined, label: 'دفع عند الاستلام'),
                        ],
                      ),
                      const SizedBox(height: 24),
                      const SectionHeader(
                        title: 'تسوق بالطريقة التي تناسبك',
                        subtitle: 'رحلة سريعة وواضحة تزيد التحويلات والمبيعات',
                      ),
                      const SizedBox(height: 14),
                      _HomeCategoryRow(onNavigateToTab: widget.onNavigateToTab),
                      const SizedBox(height: 24),
                      const SectionHeader(title: 'المناسبات', subtitle: 'اختَر حسب نوع الهدية'),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 42,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: MockStoreService.homeOccasions.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (context, index) {
                            final label = MockStoreService.homeOccasions[index];
                            return Chip(
                              label: Text(label),
                              backgroundColor: index == 0 ? AppColors.mocha : AppColors.beige,
                              labelStyle: TextStyle(
                                color: index == 0 ? Colors.white : AppColors.mocha,
                                fontWeight: FontWeight.w700,
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 24),
                      const SectionHeader(title: 'الأكثر طلبًا', actionText: 'عرض الكل'),
                    ],
                  ),
                ),
              ),
              if (loading)
                const SliverToBoxAdapter(child: _LoadingSection())
              else ...[
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 10),
                  sliver: SliverGrid.builder(
                    itemCount: (data?.featured ?? const <Product>[]).length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.62,
                      mainAxisSpacing: 14,
                      crossAxisSpacing: 14,
                    ),
                    itemBuilder: (context, index) {
                      final product = data!.featured[index];
                      return ProductCard(
                        product: product,
                        actionLabel: 'أضف',
                        onAdd: () => _addToCart(product),
                        onTap: () => _openProduct(product),
                        selected: AppCartController.instance.contains(product.id),
                      );
                    },
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 10, 20, 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 10),
                        const SectionHeader(title: 'اجمع هديتك بنفسك', subtitle: '5 خطوات بسيطة ترفع متوسط الطلب'),
                        const SizedBox(height: 12),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: AppColors.card,
                            borderRadius: BorderRadius.circular(28),
                            border: Border.all(color: AppColors.line),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                'اختَر البوكس، أضف الهدية، اكتب التهنئة، حدّد التغليف ثم راجع الطلب.',
                                style: TextStyle(height: 1.7, color: AppColors.textSecondary),
                              ),
                              const SizedBox(height: 16),
                              Wrap(
                                spacing: 8,
                                runSpacing: 8,
                                children: const [
                                  _MiniStep(label: '1. البوكس'),
                                  _MiniStep(label: '2. الهدية'),
                                  _MiniStep(label: '3. التهنئة'),
                                  _MiniStep(label: '4. التغليف'),
                                  _MiniStep(label: '5. الدفع'),
                                ],
                              ),
                              const SizedBox(height: 16),
                              SizedBox(
                                width: double.infinity,
                                child: ElevatedButton(
                                  onPressed: () => widget.onNavigateToTab(1),
                                  child: const Text('ابدأ الآن'),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 24),
                        const SectionHeader(title: 'بوكسات جاهزة', actionText: 'عرض المزيد'),
                        const SizedBox(height: 12),
                      ],
                    ),
                  ),
                ),
                _HorizontalProducts(products: data!.readyBoxes, onTap: _openProduct, onAdd: _addToCart),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 24, 20, 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        SectionHeader(title: 'أطقم القهوة', subtitle: 'هوية المتجر الأقوى بصريًا ومبيعاتيًا'),
                        SizedBox(height: 12),
                      ],
                    ),
                  ),
                ),
                _HorizontalProducts(products: data!.coffeeSets, onTap: _openProduct, onAdd: _addToCart),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20, 24, 20, 120),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SectionHeader(title: 'عروض مختارة', subtitle: 'استغل الخصومات لزيادة معدل الشراء'),
                        const SizedBox(height: 12),
                        ...data!.offers.take(3).map(
                          (product) => _OfferTile(
                            product: product,
                            onTap: () => _openProduct(product),
                            onAdd: () => _addToCart(product),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _LiveStatusBanner extends StatelessWidget {
  final bool isLive;
  final VoidCallback onRefresh;

  const _LiveStatusBanner({required this.isLive, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    final enabled = AppConfig.hasValidStorefrontToken && !AppConfig.enableMockData;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isLive ? const Color(0xFFEAF4E4) : const Color(0xFFFFF7F1),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: isLive ? const Color(0xFFCFE5C7) : AppColors.line),
      ),
      child: Row(
        children: [
          Icon(
            isLive ? Icons.cloud_done_rounded : Icons.cloud_off_rounded,
            color: isLive ? AppColors.olive : AppColors.warning,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              isLive
                  ? 'التطبيق يعرض الآن منتجات مباشرة من Shopify.'
                  : enabled
                      ? 'يمكنك التحديث لتجربة الربط المباشر إذا كانت البيانات صحيحة.'
                      : 'يعمل الآن بوضع التجربة حتى يتم وضع Public Storefront Token.',
              style: const TextStyle(fontWeight: FontWeight.w700, height: 1.5),
            ),
          ),
          TextButton(onPressed: onRefresh, child: const Text('تحديث')),
        ],
      ),
    );
  }
}

class _LoadingSection extends StatelessWidget {
  const _LoadingSection();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
      child: Column(
        children: List.generate(
          3,
          (index) => Container(
            margin: const EdgeInsets.only(bottom: 12),
            height: 110,
            decoration: BoxDecoration(
              color: AppColors.beige,
              borderRadius: BorderRadius.circular(24),
            ),
          ),
        ),
      ),
    );
  }
}

class _HorizontalProducts extends StatelessWidget {
  final List<Product> products;
  final ValueChanged<Product> onTap;
  final ValueChanged<Product> onAdd;

  const _HorizontalProducts({
    required this.products,
    required this.onTap,
    required this.onAdd,
  });

  @override
  Widget build(BuildContext context) {
    return SliverToBoxAdapter(
      child: SizedBox(
        height: 330,
        child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          scrollDirection: Axis.horizontal,
          itemCount: products.length,
          separatorBuilder: (_, __) => const SizedBox(width: 14),
          itemBuilder: (context, index) {
            final product = products[index];
            return SizedBox(
              width: 220,
              child: ProductCard(
                product: product,
                onTap: () => onTap(product),
                onAdd: () => onAdd(product),
                selected: AppCartController.instance.contains(product.id),
              ),
            );
          },
        ),
      ),
    );
  }
}

class _HomeCategoryRow extends StatelessWidget {
  final ValueChanged<int> onNavigateToTab;

  const _HomeCategoryRow({required this.onNavigateToTab});

  @override
  Widget build(BuildContext context) {
    final categories = const [
      ('اختر هديتك بنفسك', '🎁', 1),
      ('بوكسات جاهزة', '💝', 2),
      ('أطقم القهوة', '☕', 2),
      ('العروض', '🔥', 2),
    ];

    return SizedBox(
      height: 132,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, index) {
          final category = categories[index];
          return InkWell(
            onTap: () => onNavigateToTab(category.$3),
            borderRadius: BorderRadius.circular(24),
            child: Container(
              width: 164,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppColors.card,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(color: AppColors.line),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(category.$2, style: const TextStyle(fontSize: 32)),
                  const Spacer(),
                  Text(
                    category.$1,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      color: AppColors.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Text(
                    'تسوق الآن',
                    style: TextStyle(
                      color: AppColors.gold,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _TrustChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _TrustChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: AppColors.beige,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            Icon(icon, color: AppColors.mocha, size: 18),
            const SizedBox(height: 6),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.mocha,
                fontSize: 12,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _CircleIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _CircleIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.line),
        ),
        child: Icon(icon, color: AppColors.mocha, size: 20),
      ),
    );
  }
}

class _MiniStep extends StatelessWidget {
  final String label;
  const _MiniStep({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: AppColors.beige,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: AppColors.mocha,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _OfferTile extends StatelessWidget {
  final Product product;
  final VoidCallback onTap;
  final VoidCallback onAdd;

  const _OfferTile({required this.product, required this.onTap, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  color: AppColors.beige,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: product.image.startsWith('http')
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: Image.network(
                          product.image,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => const Center(child: Text('🛍️', style: TextStyle(fontSize: 30))),
                        ),
                      )
                    : Center(child: Text(product.image, style: const TextStyle(fontSize: 30))),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 6),
                    Text(product.description, maxLines: 2, overflow: TextOverflow.ellipsis),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${product.price.toStringAsFixed(0)} ج.م',
                    style: const TextStyle(color: AppColors.mocha, fontWeight: FontWeight.w900),
                  ),
                  if (product.oldPrice != null)
                    Text(
                      '${product.oldPrice!.toStringAsFixed(0)}',
                      style: const TextStyle(
                        decoration: TextDecoration.lineThrough,
                        color: AppColors.textMuted,
                        fontSize: 12,
                      ),
                    ),
                  const SizedBox(height: 8),
                  TextButton(onPressed: onAdd, child: const Text('أضف')),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
