import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/config/app_config.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/controllers/app_cart_controller.dart';
import '../../../data/controllers/order_controller.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  Future<void> _openStore(BuildContext context) async {
    final uri = Uri.parse(AppConfig.storeUrl);
    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched && context.mounted) {
      await Clipboard.setData(ClipboardData(text: AppConfig.storeUrl));
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: AppColors.olive,
          content: Text('تم نسخ رابط المتجر للحافظة.'),
        ),
      );
    }
  }

  int _readinessScore({
    required bool hasToken,
    required bool isLiveMode,
    required bool hasOrders,
    required int liveOrders,
    required int cartItems,
    required double averageOrderValue,
  }) {
    var score = 0;
    if (hasToken) score += 30;
    if (isLiveMode) score += 20;
    if (hasOrders) score += 15;
    if (liveOrders > 0) score += 20;
    if (cartItems > 0) score += 5;
    if (averageOrderValue > 0) score += 10;
    return score;
  }

  String _scoreLabel(int score) {
    if (score >= 85) return 'جاهز جدًا للخطوة الأخيرة';
    if (score >= 65) return 'قريب من الإطلاق';
    if (score >= 40) return 'تقدم قوي ولسه محتاج شوية ضبط';
    return 'ابدأ بإغلاق أساسيات الدفع والنشر';
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('الحساب ومركز الإطلاق')),
        body: AnimatedBuilder(
          animation: Listenable.merge([
            AppCartController.instance,
            OrderController.instance,
          ]),
          builder: (context, _) {
            final orders = OrderController.instance.orders;
            final hasToken = AppConfig.hasValidStorefrontToken;
            final isLiveMode = AppConfig.isLiveModeRequested;
            final liveOrders = OrderController.instance.liveOrders;
            final readinessScore = _readinessScore(
              hasToken: hasToken,
              isLiveMode: isLiveMode,
              hasOrders: orders.isNotEmpty,
              liveOrders: liveOrders,
              cartItems: AppCartController.instance.totalItems,
              averageOrderValue: OrderController.instance.averageOrderValue,
            );

            final blockers = <String>[
              if (!hasToken) 'إضافة Public Storefront Token داخل AppConfig.',
              if (orders.isEmpty) 'تنفيذ طلب تجريبي كامل وتسجيله داخل مركز الطلبات.',
              if (liveOrders == 0) 'إتمام Live Checkout واحد على الأقل للتأكد من الربط الحقيقي.',
              'تجهيز مشروع Android للتوقيع وإخراج ملف ${AppConfig.preferredReleaseArtifact}.',
            ];

            return ListView(
              padding: const EdgeInsets.all(20),
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [AppColors.mocha, Color(0xFF6A4B3A)],
                      begin: Alignment.topRight,
                      end: Alignment.bottomLeft,
                    ),
                    borderRadius: BorderRadius.circular(28),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 52,
                            height: 52,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: const Icon(Icons.rocket_launch_rounded, color: Colors.white),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text(
                                  'المرحلة السابعة',
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 20,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  _scoreLabel(readinessScore),
                                  style: const TextStyle(color: Color(0xFFF8E8D1), height: 1.5),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          _StatusChip(
                            label: hasToken ? 'Token موجود' : 'Token ناقص',
                            color: hasToken ? const Color(0xFFEAF4E4) : const Color(0xFFFFF1ED),
                            textColor: hasToken ? AppColors.olive : AppColors.error,
                          ),
                          _StatusChip(
                            label: AppConfig.dataModeLabel,
                            color: AppColors.gold,
                            textColor: AppColors.textPrimary,
                          ),
                          _StatusChip(
                            label: '${OrderController.instance.totalOrders} طلب',
                            color: AppColors.teal,
                            textColor: Colors.white,
                          ),
                          _StatusChip(
                            label: '${AppCartController.instance.totalItems} بالعربة',
                            color: AppColors.rose,
                            textColor: Colors.white,
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white24),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Expanded(
                                  child: Text(
                                    'مؤشر الجاهزية للنشر',
                                    style: TextStyle(color: Color(0xFFF8E8D1), fontWeight: FontWeight.w700),
                                  ),
                                ),
                                Text(
                                  '$readinessScore%',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w900,
                                    fontSize: 18,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(99),
                              child: LinearProgressIndicator(
                                minHeight: 10,
                                value: readinessScore / 100,
                                backgroundColor: Colors.white24,
                                valueColor: const AlwaysStoppedAnimation<Color>(AppColors.gold),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 1.25,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  children: [
                    _KpiCard(
                      title: 'الطلبات المباشرة',
                      value: '$liveOrders',
                      subtitle: 'Live checkout',
                      accent: AppColors.teal,
                      icon: Icons.cloud_done_rounded,
                    ),
                    _KpiCard(
                      title: 'متوسط السلة',
                      value: '${OrderController.instance.averageOrderValue.toStringAsFixed(0)} ج.م',
                      subtitle: 'AOV preview',
                      accent: AppColors.gold,
                      icon: Icons.auto_graph_rounded,
                    ),
                    _KpiCard(
                      title: 'إجمالي المتابعة',
                      value: '${OrderController.instance.totalSalesPreview.toStringAsFixed(0)} ج.م',
                      subtitle: 'مبيعات متوقعة',
                      accent: AppColors.olive,
                      icon: Icons.payments_rounded,
                    ),
                    _KpiCard(
                      title: 'المدينة الأبرز',
                      value: OrderController.instance.hottestCity,
                      subtitle: '${OrderController.instance.totalTrackedItems} عنصر متتبع',
                      accent: AppColors.rose,
                      icon: Icons.location_on_outlined,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Checklist الإطلاق - المرحلة السابعة',
                          style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha),
                        ),
                        const SizedBox(height: 12),
                        _LaunchCheckRow(label: 'ربط Shopify بالـ Public Token', done: hasToken),
                        _LaunchCheckRow(label: 'تفعيل وضع Live داخل التطبيق', done: isLiveMode),
                        _LaunchCheckRow(label: 'تسجيل طلبات اختبار محلية', done: orders.isNotEmpty),
                        _LaunchCheckRow(label: 'تسجيل Live Checkout حقيقي', done: liveOrders > 0),
                        _LaunchCheckRow(label: 'إخراج ${AppConfig.preferredReleaseArtifact} للتسليم', done: false),
                        _LaunchCheckRow(label: 'استهداف Android API ${AppConfig.requiredAndroidTargetApi}', done: false),
                        const SizedBox(height: 12),
                        Text(
                          blockers.isEmpty
                              ? 'ممتاز. المتجر جاهز للتحويل النهائي وتجهيز ملف النشر.'
                              : 'البلوكيرز الحالية: ${blockers.join(' • ')}',
                          style: const TextStyle(height: 1.7, color: AppColors.textSecondary),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'متطلبات النشر السريعة',
                          style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha),
                        ),
                        const SizedBox(height: 12),
                        _RequirementTile(
                          title: 'صيغة النشر',
                          value: AppConfig.preferredReleaseArtifact,
                          note: 'Google Play يطلب App Bundle للتسليم.',
                          accent: AppColors.teal,
                        ),
                        _RequirementTile(
                          title: 'Target API',
                          value: 'Android ${AppConfig.requiredAndroidTargetApi}',
                          note: 'لازم إعداد Android project قبل التسليم النهائي.',
                          accent: AppColors.gold,
                        ),
                        _RequirementTile(
                          title: 'الدفع الإلكتروني',
                          value: hasToken ? 'جاهز مبدئيًا' : 'ينتظر Token',
                          note: 'الربط الحالي سليم من ناحية Flutter، والمتبقي إدخال القيم الحية.',
                          accent: hasToken ? AppColors.olive : AppColors.error,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: () => _openStore(context),
                        icon: const Icon(Icons.language_rounded),
                        label: const Text('افتح المتجر'),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: orders.isEmpty ? null : OrderController.instance.clear,
                        icon: const Icon(Icons.delete_outline_rounded),
                        label: const Text('مسح الطلبات'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                const Text(
                  'الطلبات الأخيرة',
                  style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha, fontSize: 18),
                ),
                const SizedBox(height: 12),
                if (orders.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: AppColors.line),
                    ),
                    child: const Column(
                      children: [
                        Icon(Icons.inventory_2_outlined, size: 42, color: AppColors.textMuted),
                        SizedBox(height: 12),
                        Text(
                          'لا توجد طلبات محفوظة بعد',
                          style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
                        ),
                        SizedBox(height: 8),
                        Text(
                          'نفّذ طلب تجريبي أو Checkout حي وابدأ بناء لوحة أداء تساعدك تكسر 200,000 شهريًا.',
                          textAlign: TextAlign.center,
                          style: TextStyle(height: 1.6),
                        ),
                      ],
                    ),
                  )
                else
                  ...orders.take(8).map(
                    (order) => Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    order.id,
                                    style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha),
                                  ),
                                ),
                                _StatusChip(
                                  label: order.status,
                                  color: order.isLiveCheckout ? const Color(0xFFEAF4E4) : const Color(0xFFFFF7F1),
                                  textColor: order.isLiveCheckout ? AppColors.olive : AppColors.mocha,
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            _InfoLine(label: 'العميل', value: order.customerName),
                            _InfoLine(label: 'الدفع', value: order.paymentMethod),
                            _InfoLine(label: 'الشحن', value: '${order.city} - ${order.address}'),
                            _InfoLine(label: 'الإجمالي', value: '${order.total.toStringAsFixed(0)} ج.م'),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: order.itemSummaries
                                  .take(4)
                                  .map(
                                    (item) => Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                      decoration: BoxDecoration(
                                        color: AppColors.beige,
                                        borderRadius: BorderRadius.circular(14),
                                      ),
                                      child: Text(
                                        item,
                                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                                      ),
                                    ),
                                  )
                                  .toList(),
                            ),
                            if (order.checkoutUrl != null && order.checkoutUrl!.isNotEmpty) ...[
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: OutlinedButton.icon(
                                      onPressed: () async {
                                        final launched = await launchUrl(
                                          Uri.parse(order.checkoutUrl!),
                                          mode: LaunchMode.externalApplication,
                                        );
                                        if (!launched && context.mounted) {
                                          await Clipboard.setData(ClipboardData(text: order.checkoutUrl!));
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            const SnackBar(
                                              backgroundColor: AppColors.olive,
                                              content: Text('تم نسخ رابط الـ Checkout للحافظة.'),
                                            ),
                                          );
                                        }
                                      },
                                      icon: const Icon(Icons.open_in_new_rounded),
                                      label: const Text('افتح Checkout'),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _KpiCard extends StatelessWidget {
  final String title;
  final String value;
  final String subtitle;
  final Color accent;
  final IconData icon;

  const _KpiCard({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.accent,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: accent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: accent),
          ),
          const Spacer(),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha, fontSize: 18),
          ),
          const SizedBox(height: 4),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 2),
          Text(subtitle, style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
        ],
      ),
    );
  }
}

class _RequirementTile extends StatelessWidget {
  final String title;
  final String value;
  final String note;
  final Color accent;

  const _RequirementTile({
    required this.title,
    required this.value,
    required this.note,
    required this.accent,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.beige,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: accent.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.checklist_rounded, color: accent, size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha)),
                const SizedBox(height: 4),
                Text(value, style: const TextStyle(fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(note, style: const TextStyle(height: 1.6, color: AppColors.textSecondary, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  final String label;
  final Color color;
  final Color textColor;

  const _StatusChip({required this.label, required this.color, required this.textColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(14)),
      child: Text(
        label,
        style: TextStyle(color: textColor, fontWeight: FontWeight.w800, fontSize: 12),
      ),
    );
  }
}

class _LaunchCheckRow extends StatelessWidget {
  final String label;
  final bool done;

  const _LaunchCheckRow({required this.label, required this.done});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Icon(
            done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
            color: done ? AppColors.olive : AppColors.textMuted,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                fontWeight: FontWeight.w700,
                color: done ? AppColors.textPrimary : AppColors.textMuted,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  final String label;
  final String value;

  const _InfoLine({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 74,
            child: Text(
              label,
              style: const TextStyle(color: AppColors.textMuted, fontWeight: FontWeight.w700),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w700, height: 1.5),
            ),
          ),
        ],
      ),
    );
  }
}
