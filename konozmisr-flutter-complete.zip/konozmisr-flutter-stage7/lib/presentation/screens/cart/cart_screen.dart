import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/config/app_config.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/controllers/app_cart_controller.dart';
import '../../../data/controllers/order_controller.dart';
import '../../../data/models/order_record.dart';
import '../../../data/models/shopify_cart.dart';
import '../../../data/services/shopify_service.dart';

enum _PaymentMethod { shopify, cashOnDelivery, bankTransfer }

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final ShopifyService _shopifyService = ShopifyService();
  final nameController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();
  final cityController = TextEditingController();
  final areaController = TextEditingController();
  final addressController = TextEditingController();
  final noteController = TextEditingController();
  bool loading = false;
  String? errorMessage;
  String? checkoutUrl;
  ShopifyCart? cart;
  _PaymentMethod paymentMethod = _PaymentMethod.shopify;

  @override
  void dispose() {
    nameController.dispose();
    emailController.dispose();
    phoneController.dispose();
    cityController.dispose();
    areaController.dispose();
    addressController.dispose();
    noteController.dispose();
    super.dispose();
  }

  bool get _hasToken => AppConfig.hasValidStorefrontToken;

  List get _localItems => AppCartController.instance.items;

  List get _liveEligibleItems =>
      _localItems.where((item) => item.product.variantId != null && item.product.variantId!.isNotEmpty).toList();

  bool get _cartFullyLiveReady => _localItems.isNotEmpty && _liveEligibleItems.length == _localItems.length;

  double get _shippingFee {
    final city = cityController.text.trim();
    if (city.isEmpty) return 0;
    if (city.contains('القاهرة') || city.contains('الجيزة')) return 80;
    if (city.contains('الإسكندرية')) return 95;
    if (city.contains('المنصورة') || city.contains('طنطا')) return 100;
    return 110;
  }

  double get _grandTotal => AppCartController.instance.subtotal + _shippingFee;

  void _fillDemoCustomer() {
    setState(() {
      nameController.text = 'عميل اختبار كنوز مصر';
      emailController.text = 'test@konozmisr.com';
      phoneController.text = '+201000000000';
      cityController.text = 'القاهرة';
      areaController.text = 'مدينة نصر';
      addressController.text = 'شارع عباس العقاد، عمارة 10، الدور 3';
      noteController.text = 'سيناريو مرحلة 7 قبل الإطلاق.';
    });
    _showMessage('تم ملء بيانات اختبار جاهزة لجولة QA سريعة.', isError: false);
  }

  void _applyCityPreset(String city, String area) {
    setState(() {
      cityController.text = city;
      areaController.text = area;
    });
  }

  bool _validateCustomerFields({required bool emailRequired}) {
    if (_localItems.isEmpty) {
      _showMessage('العربة فارغة. أضف منتجات أولاً.', isError: true);
      return false;
    }
    if (nameController.text.trim().isEmpty) {
      _showMessage('اكتب اسم العميل لإكمال الطلب.', isError: true);
      return false;
    }
    if (phoneController.text.trim().isEmpty) {
      _showMessage('اكتب رقم الهاتف لإكمال الطلب.', isError: true);
      return false;
    }
    if (cityController.text.trim().isEmpty) {
      _showMessage('اكتب المدينة لحساب الشحن التقديري.', isError: true);
      return false;
    }
    if (addressController.text.trim().isEmpty) {
      _showMessage('اكتب عنوان الشحن بالتفصيل.', isError: true);
      return false;
    }
    if (emailRequired && emailController.text.trim().isEmpty) {
      _showMessage('البريد الإلكتروني مطلوب لتجهيز Shopify Checkout.', isError: true);
      return false;
    }
    return true;
  }

  Future<void> _prepareCheckout() async {
    if (!_validateCustomerFields(emailRequired: true)) return;

    setState(() {
      loading = true;
      errorMessage = null;
    });

    try {
      if (!_hasToken) {
        throw Exception('أضف Public Storefront Token أولاً داخل AppConfig لتفعيل Shopify Checkout الحقيقي.');
      }

      if (!_cartFullyLiveReady) {
        throw Exception('بعض العناصر داخل العربة تجريبية أو مخصصة بدون Variant IDs، لذلك لا يمكن إرسال العربة بالكامل إلى Shopify Checkout حالياً.');
      }

      final lines = _liveEligibleItems
          .map((item) => {
                'merchandiseId': item.product.variantId,
                'quantity': item.quantity,
              })
          .toList();

      final createdCart = await _shopifyService.createCart(lines: lines.cast<Map<String, dynamic>>());
      final updatedCart = await _shopifyService.updateBuyerIdentity(
        cartId: createdCart.id,
        email: emailController.text.trim(),
        phone: phoneController.text.trim(),
      );

      setState(() {
        cart = updatedCart;
        checkoutUrl = updatedCart.checkoutUrl;
      });

      OrderController.instance.addOrder(
        _buildOrderRecord(
          orderId: updatedCart.id,
          status: 'بانتظار الدفع الإلكتروني',
          isLiveCheckout: true,
          checkoutUrlOverride: updatedCart.checkoutUrl,
        ),
      );

      if (!mounted) return;
      _showMessage('تم تجهيز Shopify Checkout بنجاح. افتح الرابط وكمل الطلب مباشرة.', isError: false);
    } catch (e) {
      setState(() => errorMessage = e.toString());
    } finally {
      if (mounted) {
        setState(() => loading = false);
      }
    }
  }

  Future<void> _openCheckout() async {
    final url = checkoutUrl;
    if (url == null || url.isEmpty) {
      _showMessage('جهّز الـ Checkout أولاً ثم افتح الرابط.', isError: true);
      return;
    }

    final uri = Uri.parse(url);
    final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!launched && mounted) {
      await Clipboard.setData(ClipboardData(text: url));
      _showMessage('تعذر فتح الرابط تلقائيًا، تم نسخه للحافظة.', isError: false);
    }
  }

  Future<void> _submitTestOrder() async {
    if (!_validateCustomerFields(emailRequired: false)) return;

    final orderCode = 'KM-${DateTime.now().millisecondsSinceEpoch.toString().substring(7)}';
    final itemsSummary = _localItems
        .map((item) => '• ${item.product.title} × ${item.quantity} — ${item.total.toStringAsFixed(0)} ج.م')
        .join('\n');
    final testOrder = _buildOrderRecord(
      orderId: orderCode,
      status: paymentMethod == _PaymentMethod.cashOnDelivery
          ? 'بانتظار تأكيد الطلب'
          : 'بانتظار مراجعة التحويل',
      isLiveCheckout: false,
    );

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Container(
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(28),
          ),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: const Color(0xFFEAF4E4),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Icon(Icons.check_circle_rounded, color: AppColors.olive),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text(
                        'تم تجهيز طلب تجريبي كامل',
                        style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: AppColors.mocha),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                _InfoRow(label: 'رقم الطلب', value: orderCode),
                _InfoRow(label: 'العميل', value: nameController.text.trim()),
                _InfoRow(label: 'الهاتف', value: phoneController.text.trim()),
                _InfoRow(label: 'الشحن', value: '${cityController.text.trim()} - ${addressController.text.trim()}'),
                _InfoRow(label: 'الدفع', value: _paymentLabel(paymentMethod)),
                const SizedBox(height: 10),
                const Text(
                  'ملخص العناصر',
                  style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
                ),
                const SizedBox(height: 8),
                Text(itemsSummary, style: const TextStyle(height: 1.7)),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFF7F1),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: AppColors.line),
                  ),
                  child: Column(
                    children: [
                      _MoneyRow(label: 'الإجمالي المحلي', value: AppCartController.instance.subtotal),
                      _MoneyRow(label: 'الشحن التقديري', value: _shippingFee),
                      _MoneyRow(label: 'الإجمالي النهائي', value: _grandTotal, bold: true),
                    ],
                  ),
                ),
                if (noteController.text.trim().isNotEmpty) ...[
                  const SizedBox(height: 12),
                  _InfoRow(label: 'ملاحظات', value: noteController.text.trim()),
                ],
                const SizedBox(height: 18),
                ElevatedButton.icon(
                  onPressed: () {
                    OrderController.instance.addOrder(testOrder);
                    Navigator.of(context).pop();
                    AppCartController.instance.clear();
                    setState(() {
                      cart = null;
                      checkoutUrl = null;
                      errorMessage = null;
                    });
                    _showMessage('تم إنهاء سيناريو الاختبار بنجاح. التطبيق جاهز لجولة اختبار موبايل قوية.', isError: false);
                  },
                  icon: const Icon(Icons.rocket_launch_rounded),
                  label: const Text('إنهاء الاختبار ومسح العربة'),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showMessage(String message, {required bool isError}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: isError ? AppColors.error : AppColors.olive,
        content: Text(message),
      ),
    );
  }

  String _paymentLabel(_PaymentMethod method) {
    switch (method) {
      case _PaymentMethod.shopify:
        return 'Shopify Checkout / دفع إلكتروني';
      case _PaymentMethod.cashOnDelivery:
        return 'الدفع عند الاستلام';
      case _PaymentMethod.bankTransfer:
        return 'تحويل بنكي';
    }
  }

  OrderRecord _buildOrderRecord({
    required String orderId,
    required String status,
    required bool isLiveCheckout,
    String? checkoutUrlOverride,
  }) {
    return OrderRecord(
      id: orderId,
      customerName: nameController.text.trim(),
      phone: phoneController.text.trim(),
      city: cityController.text.trim(),
      address: addressController.text.trim(),
      paymentMethod: _paymentLabel(paymentMethod),
      status: status,
      total: _grandTotal,
      createdAt: DateTime.now(),
      itemSummaries: _localItems
          .map((item) => '${item.product.title} × ${item.quantity}')
          .toList()
          .cast<String>(),
      checkoutUrl: checkoutUrlOverride,
      isLiveCheckout: isLiveCheckout,
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: const Text('العربة والدفع')),
        body: AnimatedBuilder(
          animation: AppCartController.instance,
          builder: (context, _) {
            final localItems = AppCartController.instance.items;
            final hasCustomItems = localItems.any((item) => item.product.isCustomGift);

            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 120),
              children: [
                _StatusBanner(
                  hasToken: _hasToken,
                  fullyLiveReady: _cartFullyLiveReady,
                  hasCustomItems: hasCustomItems,
                  paymentLabel: _paymentLabel(paymentMethod),
                ),
                const SizedBox(height: 10),
                AnimatedBuilder(
                  animation: OrderController.instance,
                  builder: (context, _) {
                    return Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.card,
                        borderRadius: BorderRadius.circular(18),
                        border: Border.all(color: AppColors.line),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.receipt_long_rounded, color: AppColors.teal),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'مركز الطلبات: ${OrderController.instance.totalOrders} طلب • ${OrderController.instance.pendingOrders} قيد المتابعة',
                              style: const TextStyle(fontWeight: FontWeight.w800, height: 1.5),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
                const SizedBox(height: 14),
                const _CheckoutProgress(),
                const SizedBox(height: 16),
                const Text(
                  'عناصر العربة',
                  style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha, fontSize: 18),
                ),
                const SizedBox(height: 12),
                if (localItems.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(22),
                      border: Border.all(color: AppColors.line),
                    ),
                    child: const Column(
                      children: [
                        Icon(Icons.shopping_bag_outlined, color: AppColors.textMuted, size: 42),
                        SizedBox(height: 12),
                        Text('العربة فارغة حالياً', style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha)),
                        SizedBox(height: 8),
                        Text('ابدأ بإضافة منتجات أو أنشئ بوكس مخصص من Gift Builder.'),
                      ],
                    ),
                  )
                else
                  ...localItems.map(
                    (item) => Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 56,
                                  height: 56,
                                  decoration: BoxDecoration(
                                    color: AppColors.beige,
                                    borderRadius: BorderRadius.circular(18),
                                  ),
                                  child: item.product.image.toString().startsWith('http')
                                      ? ClipRRect(
                                          borderRadius: BorderRadius.circular(18),
                                          child: Image.network(
                                            item.product.image,
                                            fit: BoxFit.cover,
                                            errorBuilder: (_, __, ___) => const Center(child: Text('🛍️', style: TextStyle(fontSize: 30))),
                                          ),
                                        )
                                      : Center(child: Text(item.product.image, style: const TextStyle(fontSize: 30))),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(item.product.title, style: const TextStyle(fontWeight: FontWeight.w800)),
                                      const SizedBox(height: 6),
                                      Text(item.product.category, style: const TextStyle(color: AppColors.textMuted)),
                                      const SizedBox(height: 6),
                                      Wrap(
                                        spacing: 6,
                                        runSpacing: 6,
                                        children: [
                                          _StatusPill(
                                            label: item.product.isCustomGift ? 'بوكس مخصص' : 'منتج',
                                            color: item.product.isCustomGift ? AppColors.rose : AppColors.beige,
                                            textColor: item.product.isCustomGift ? Colors.white : AppColors.mocha,
                                          ),
                                          _StatusPill(
                                            label: item.product.variantId != null ? 'جاهز لـ Shopify' : 'تجريبي',
                                            color: item.product.variantId != null ? const Color(0xFFEAF4E4) : const Color(0xFFFFF1ED),
                                            textColor: item.product.variantId != null ? AppColors.olive : AppColors.error,
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  onPressed: () => AppCartController.instance.removeProduct(item.product.id),
                                  icon: const Icon(Icons.delete_outline_rounded, color: AppColors.error),
                                ),
                              ],
                            ),
                            if (item.product.orderSummary != null) ...[
                              const SizedBox(height: 12),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.all(12),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFFFFBF5),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(color: AppColors.line),
                                ),
                                child: Text(
                                  item.product.orderSummary!,
                                  style: const TextStyle(height: 1.7, fontSize: 12),
                                ),
                              ),
                            ],
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Text(
                                  '${item.total.toStringAsFixed(0)} ج.م',
                                  style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha),
                                ),
                                const Spacer(),
                                _QtyAction(
                                  icon: Icons.add,
                                  onTap: () => AppCartController.instance.addProduct(item.product),
                                ),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 10),
                                  child: Text('${item.quantity}', style: const TextStyle(fontWeight: FontWeight.w900)),
                                ),
                                _QtyAction(
                                  icon: Icons.remove,
                                  onTap: () => AppCartController.instance.decreaseProduct(item.product.id),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 18),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const Expanded(
                              child: Text(
                                'بيانات العميل والشحن',
                                style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
                              ),
                            ),
                            OutlinedButton.icon(
                              onPressed: _fillDemoCustomer,
                              icon: const Icon(Icons.bolt_rounded),
                              label: const Text('بيانات اختبار'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'اختصار ممتاز لاختبار الرحلة كاملة على الموبايل في أقل من دقيقة.',
                          style: TextStyle(color: AppColors.textSecondary, height: 1.6),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: nameController,
                          decoration: const InputDecoration(labelText: 'اسم العميل'),
                          onChanged: (_) => setState(() {}),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(labelText: 'البريد الإلكتروني'),
                          onChanged: (_) => setState(() {}),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: phoneController,
                          keyboardType: TextInputType.phone,
                          decoration: const InputDecoration(labelText: 'رقم الهاتف'),
                          onChanged: (_) => setState(() {}),
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: cityController,
                                decoration: const InputDecoration(labelText: 'المدينة'),
                                onChanged: (_) => setState(() {}),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: TextField(
                                controller: areaController,
                                decoration: const InputDecoration(labelText: 'المنطقة'),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            _PresetChip(label: 'القاهرة', onTap: () => _applyCityPreset('القاهرة', 'مدينة نصر')),
                            _PresetChip(label: 'الجيزة', onTap: () => _applyCityPreset('الجيزة', 'الدقي')),
                            _PresetChip(label: 'الإسكندرية', onTap: () => _applyCityPreset('الإسكندرية', 'سموحة')),
                            _PresetChip(label: 'المنصورة', onTap: () => _applyCityPreset('المنصورة', 'حي الجامعة')),
                          ],
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: addressController,
                          maxLines: 2,
                          decoration: const InputDecoration(labelText: 'العنوان بالتفصيل'),
                          onChanged: (_) => setState(() {}),
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: noteController,
                          maxLines: 3,
                          decoration: const InputDecoration(labelText: 'ملاحظات الطلب أو التوصيل'),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                const Text(
                  'اختَر طريقة الدفع',
                  style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha, fontSize: 18),
                ),
                const SizedBox(height: 12),
                _PaymentOptionCard(
                  title: 'Shopify Checkout',
                  subtitle: _cartFullyLiveReady
                      ? 'أفضل اختيار لو المنتجات كلها مربوطة Variant IDs.'
                      : 'يحتاج Token صحيح وكل العناصر تكون Live-ready.',
                  active: paymentMethod == _PaymentMethod.shopify,
                  accent: AppColors.teal,
                  icon: Icons.lock_outline_rounded,
                  onTap: () => setState(() => paymentMethod = _PaymentMethod.shopify),
                ),
                _PaymentOptionCard(
                  title: 'الدفع عند الاستلام',
                  subtitle: 'سيناريو ممتاز لاختبار تجربة الطلب على الموبايل قبل النشر.',
                  active: paymentMethod == _PaymentMethod.cashOnDelivery,
                  accent: AppColors.olive,
                  icon: Icons.payments_outlined,
                  onTap: () => setState(() => paymentMethod = _PaymentMethod.cashOnDelivery),
                ),
                _PaymentOptionCard(
                  title: 'تحويل بنكي',
                  subtitle: 'اختبار واجهة بديلة للطلبات الخاصة أو الشركات.',
                  active: paymentMethod == _PaymentMethod.bankTransfer,
                  accent: AppColors.gold,
                  icon: Icons.account_balance_outlined,
                  onTap: () => setState(() => paymentMethod = _PaymentMethod.bankTransfer),
                ),
                const SizedBox(height: 18),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'الملخص النهائي',
                          style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
                        ),
                        const SizedBox(height: 12),
                        _MoneyRow(label: 'عدد المنتجات', value: AppCartController.instance.totalItems.toDouble(), suffix: 'قطعة'),
                        _MoneyRow(label: 'الإجمالي المحلي', value: AppCartController.instance.subtotal),
                        _MoneyRow(label: 'الشحن التقديري', value: _shippingFee),
                        const Divider(height: 24),
                        _MoneyRow(label: 'الإجمالي المتوقع', value: _grandTotal, bold: true),
                      ],
                    ),
                  ),
                ),
                if (errorMessage != null) ...[
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFFF1ED),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(color: const Color(0xFFF2C8BC)),
                    ),
                    child: Text(
                      errorMessage!,
                      style: const TextStyle(
                        color: AppColors.error,
                        fontWeight: FontWeight.w700,
                        height: 1.6,
                      ),
                    ),
                  ),
                ],
                if (cart != null) ...[
                  const SizedBox(height: 14),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'ملخص العربة المرتبطة بـ Shopify',
                            style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
                          ),
                          const SizedBox(height: 12),
                          _InfoRow(label: 'Cart ID', value: cart!.id),
                          _InfoRow(label: 'عدد العناصر', value: '${cart!.totalQuantity}'),
                          _InfoRow(label: 'الإجمالي الفرعي', value: '${cart!.subtotalAmount.toStringAsFixed(0)} ج.م'),
                          _InfoRow(label: 'Checkout URL', value: checkoutUrl ?? '-'),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              Expanded(
                                child: ElevatedButton.icon(
                                  onPressed: _openCheckout,
                                  icon: const Icon(Icons.open_in_new_rounded),
                                  label: const Text('افتح الـ Checkout'),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: OutlinedButton.icon(
                                  onPressed: () async {
                                    if (checkoutUrl == null) return;
                                    await Clipboard.setData(ClipboardData(text: checkoutUrl!));
                                    if (!context.mounted) return;
                                    _showMessage('تم نسخ رابط الـ Checkout.', isError: false);
                                  },
                                  icon: const Icon(Icons.copy_rounded),
                                  label: const Text('نسخ الرابط'),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ],
            );
          },
        ),
        bottomSheet: Container(
          padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
          decoration: const BoxDecoration(
            color: AppColors.card,
            border: Border(top: BorderSide(color: AppColors.line)),
          ),
          child: SafeArea(
            top: false,
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _paymentLabel(paymentMethod),
                        style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '${_grandTotal.toStringAsFixed(0)} ج.م',
                        style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.olive),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: loading
                        ? null
                        : (paymentMethod == _PaymentMethod.shopify && _hasToken && _cartFullyLiveReady
                            ? _prepareCheckout
                            : _submitTestOrder),
                    icon: loading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                          )
                        : Icon(paymentMethod == _PaymentMethod.shopify && _hasToken && _cartFullyLiveReady
                            ? Icons.lock_outline_rounded
                            : Icons.rocket_launch_rounded),
                    label: Text(
                      loading
                          ? 'جاري التجهيز...'
                          : (paymentMethod == _PaymentMethod.shopify && _hasToken && _cartFullyLiveReady
                              ? 'تهيئة Checkout'
                              : 'اختبار الطلب'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StatusBanner extends StatelessWidget {
  final bool hasToken;
  final bool fullyLiveReady;
  final bool hasCustomItems;
  final String paymentLabel;

  const _StatusBanner({
    required this.hasToken,
    required this.fullyLiveReady,
    required this.hasCustomItems,
    required this.paymentLabel,
  });

  @override
  Widget build(BuildContext context) {
    final ready = hasToken && fullyLiveReady;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: ready ? const Color(0xFFEAF4E4) : const Color(0xFFFFF1ED),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Icon(
                    ready ? Icons.check_circle : Icons.warning_amber_rounded,
                    color: ready ? AppColors.olive : AppColors.error,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'حالة الدفع الحالية',
                        style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha),
                      ),
                      const SizedBox(height: 4),
                      Text(ready ? 'جاهز لفتح Shopify Checkout الحقيقي' : 'جاهز لاختبار سيناريو طلب كامل على الموبايل'),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              ready
                  ? 'المتجر دلوقتي قريب جدًا من إصدار اختباري قوي، ودي خطوة ممتازة في طريق الوصول لمبيعات تتجاوز 200,000 شهريًا.'
                  : 'لو عندك عناصر مخصصة أو Token غير موجود، ما زال بإمكانك اختبار تجربة العميل كاملة محليًا قبل النشر.',
              style: const TextStyle(height: 1.7),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _StatusPill(
                  label: hasToken ? 'Token موجود' : 'Token ناقص',
                  color: hasToken ? const Color(0xFFEAF4E4) : const Color(0xFFFFF1ED),
                  textColor: hasToken ? AppColors.olive : AppColors.error,
                ),
                _StatusPill(
                  label: fullyLiveReady ? 'العربة Live-ready' : 'العربة Mixed/Test',
                  color: fullyLiveReady ? AppColors.beige : const Color(0xFFFFF7F1),
                  textColor: AppColors.mocha,
                ),
                if (hasCustomItems)
                  const _StatusPill(
                    label: 'يوجد بوكسات مخصصة',
                    color: AppColors.rose,
                    textColor: Colors.white,
                  ),
                _StatusPill(
                  label: paymentLabel,
                  color: AppColors.teal,
                  textColor: Colors.white,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _CheckoutProgress extends StatelessWidget {
  const _CheckoutProgress();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.line),
      ),
      child: const Row(
        children: [
          Expanded(child: _ProgressStep(title: 'العربة', done: true, active: true)),
          Expanded(child: _ProgressStep(title: 'البيانات', done: false, active: true)),
          Expanded(child: _ProgressStep(title: 'الدفع', done: false, active: false)),
        ],
      ),
    );
  }
}

class _ProgressStep extends StatelessWidget {
  final String title;
  final bool done;
  final bool active;

  const _ProgressStep({required this.title, required this.done, required this.active});

  @override
  Widget build(BuildContext context) {
    final color = done || active ? AppColors.mocha : AppColors.textMuted;
    return Column(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: done ? AppColors.gold : (active ? AppColors.mocha : AppColors.beige),
            shape: BoxShape.circle,
          ),
          child: Icon(done ? Icons.check : Icons.circle, color: Colors.white, size: done ? 18 : 10),
        ),
        const SizedBox(height: 8),
        Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 12)),
      ],
    );
  }
}

class _QtyAction extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _QtyAction({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
          color: AppColors.beige,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Icon(icon, size: 16, color: AppColors.mocha),
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;

  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 92,
            child: Text(
              label,
              style: const TextStyle(color: AppColors.textMuted, fontWeight: FontWeight.w700),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(color: AppColors.textPrimary, fontWeight: FontWeight.w700, height: 1.5),
            ),
          ),
        ],
      ),
    );
  }
}

class _PaymentOptionCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool active;
  final Color accent;
  final IconData icon;
  final VoidCallback onTap;

  const _PaymentOptionCard({
    required this.title,
    required this.subtitle,
    required this.active,
    required this.accent,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: BorderSide(color: active ? accent : AppColors.line, width: active ? 1.4 : 1),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(22),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: accent.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(icon, color: accent),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha)),
                    const SizedBox(height: 4),
                    Text(subtitle, style: const TextStyle(height: 1.6)),
                  ],
                ),
              ),
              Icon(active ? Icons.check_circle_rounded : Icons.circle_outlined, color: active ? accent : AppColors.textMuted),
            ],
          ),
        ),
      ),
    );
  }
}

class _PresetChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;

  const _PresetChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ActionChip(
      onPressed: onTap,
      backgroundColor: AppColors.beige,
      side: const BorderSide(color: AppColors.line),
      label: Text(
        label,
        style: const TextStyle(color: AppColors.mocha, fontWeight: FontWeight.w800),
      ),
      avatar: const Icon(Icons.location_on_outlined, size: 16, color: AppColors.mocha),
    );
  }
}

class _StatusPill extends StatelessWidget {
  final String label;
  final Color color;
  final Color textColor;

  const _StatusPill({required this.label, required this.color, required this.textColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(14)),
      child: Text(label, style: TextStyle(color: textColor, fontWeight: FontWeight.w800, fontSize: 12)),
    );
  }
}

class _MoneyRow extends StatelessWidget {
  final String label;
  final double value;
  final bool bold;
  final String suffix;

  const _MoneyRow({required this.label, required this.value, this.bold = false, this.suffix = 'ج.م'});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                color: bold ? AppColors.mocha : AppColors.textMuted,
                fontWeight: bold ? FontWeight.w800 : FontWeight.w700,
              ),
            ),
          ),
          Text(
            suffix == 'ج.م' ? '${value.toStringAsFixed(0)} $suffix' : '${value.toStringAsFixed(0)} $suffix',
            style: TextStyle(
              color: bold ? AppColors.mocha : AppColors.textPrimary,
              fontWeight: bold ? FontWeight.w900 : FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
