import 'package:flutter/material.dart';

import '../../../core/theme/app_theme.dart';
import '../../../data/controllers/app_cart_controller.dart';
import '../../../data/models/gift_builder_state.dart';
import '../../../data/models/product.dart';
import '../../../data/services/mock_store_service.dart';
import '../../widgets/product_card.dart';
import '../product/product_detail_screen.dart';

class GiftBuilderScreen extends StatefulWidget {
  final VoidCallback? onNavigateToCart;

  const GiftBuilderScreen({super.key, this.onNavigateToCart});

  @override
  State<GiftBuilderScreen> createState() => _GiftBuilderScreenState();
}

class _GiftBuilderScreenState extends State<GiftBuilderScreen> {
  GiftBuilderState state = const GiftBuilderState();
  String currentCategory = MockStoreService.giftCategories.first;
  final recipientController = TextEditingController();
  final senderController = TextEditingController();
  final messageController = TextEditingController();
  final searchController = TextEditingController();
  final Set<String> selectedAddons = <String>{};
  String selectedTemplate = '';

  final stepTitles = const ['البوكس', 'الهدية', 'التهنئة', 'التغليف', 'المراجعة'];

  double get addonsTotal => selectedAddons.fold(
        0,
        (sum, item) => sum + (MockStoreService.addonPrices[item] ?? 0),
      );

  double get productsTotal => state.selectedProducts.fold(0.0, (sum, item) => sum + item.price);

  double get grandTotal => state.subtotal + addonsTotal;

  List<Product> get filteredProducts {
    final query = searchController.text.trim();
    return MockStoreService.builderProducts.where((product) {
      final matchesCategory = product.category == currentCategory;
      final matchesQuery = query.isEmpty ||
          product.title.contains(query) ||
          product.description.contains(query) ||
          product.category.contains(query);
      return matchesCategory && matchesQuery;
    }).toList();
  }

  @override
  void dispose() {
    recipientController.dispose();
    senderController.dispose();
    messageController.dispose();
    searchController.dispose();
    super.dispose();
  }

  void nextStep() {
    if (!_validateCurrentStep()) return;

    if (state.currentStep < 4) {
      setState(() => state = state.copyWith(currentStep: state.currentStep + 1));
      return;
    }

    _completeGiftOrder();
  }

  void previousStep() {
    if (state.currentStep > 0) {
      setState(() => state = state.copyWith(currentStep: state.currentStep - 1));
    }
  }

  bool _validateCurrentStep() {
    switch (state.currentStep) {
      case 0:
        if (state.selectedBox == null) {
          _showError('اختَر البوكس أولاً قبل الانتقال للمرحلة التالية.');
          return false;
        }
        break;
      case 1:
        if (state.selectedProducts.isEmpty) {
          _showError('أضف منتجًا واحدًا على الأقل داخل الهدية.');
          return false;
        }
        break;
      case 2:
        if (recipientController.text.trim().isEmpty) {
          _showError('اكتب اسم المُرسل إليه لإكمال بطاقة التهنئة.');
          return false;
        }
        if (messageController.text.trim().isEmpty) {
          _showError('أضف رسالة تهنئة أو اختر رسالة جاهزة.');
          return false;
        }
        break;
      case 3:
        if (state.wrapOption == null) {
          _showError('اختَر نوع التغليف قبل مراجعة الطلب.');
          return false;
        }
        break;
      default:
        break;
    }

    return true;
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(backgroundColor: AppColors.error, content: Text(message)),
    );
  }

  void _openProduct(Product product) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product)),
    );
  }

  void _completeGiftOrder() {
    final customGift = _buildCustomGiftProduct();
    AppCartController.instance.addProduct(customGift);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.olive,
        content: Text('تمت إضافة ${customGift.title} إلى العربة. الخطوة الجاية إنك تراجع الطلب وتبدأ الشراء.'),
      ),
    );

    _resetBuilder();
    widget.onNavigateToCart?.call();
  }

  Product _buildCustomGiftProduct() {
    final title = 'بوكس مخصص - ${state.occasion}';
    final addonsText = selectedAddons.isEmpty ? 'بدون إضافات' : selectedAddons.join(' • ');
    final summary = [
      'البوكس: ${state.selectedBox?.name ?? '-'}',
      'الهدايا: ${state.selectedProducts.map((e) => e.title).join(' • ')}',
      'المناسبة: ${state.occasion}',
      'إلى: ${recipientController.text.trim().isEmpty ? '-' : recipientController.text.trim()}',
      'من: ${senderController.text.trim().isEmpty ? '-' : senderController.text.trim()}',
      'الرسالة: ${messageController.text.trim().isEmpty ? '-' : messageController.text.trim()}',
      'التغليف: ${state.wrapOption?.title ?? '-'}',
      'الإضافات: $addonsText',
    ].join('\n');

    return Product(
      id: 'custom-${DateTime.now().millisecondsSinceEpoch}',
      title: title,
      category: 'جمع هديتك بنفسك',
      image: state.selectedBox?.image ?? '🎁',
      price: grandTotal,
      description: 'طلب مخصص تم تجهيزه من خلال Gift Builder داخل تطبيق كنوز مصر.',
      compatibility: 'طلب مخصص جاهز للمراجعة النهائية داخل العربة',
      badge: 'مخصص',
      isCustomGift: true,
      orderSummary: summary,
    );
  }

  void _resetBuilder() {
    setState(() {
      state = const GiftBuilderState();
      currentCategory = MockStoreService.giftCategories.first;
      selectedTemplate = '';
      selectedAddons.clear();
      recipientController.clear();
      senderController.clear();
      messageController.clear();
      searchController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.ivory,
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 8),
              child: Row(
                children: [
                  IconButton(
                    onPressed: state.currentStep == 0 ? null : previousStep,
                    icon: const Icon(Icons.arrow_back_ios_new_rounded),
                  ),
                  Expanded(
                    child: Column(
                      children: [
                        Text(
                          'اختر هديتك بنفسك',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'الخطوة ${state.currentStep + 1} من 5',
                          style: const TextStyle(color: AppColors.textMuted),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        backgroundColor: AppColors.teal,
                        content: Text('تم حفظ مسودة محلية للتجربة. بعد الربط النهائي هنفعل الحفظ الحقيقي.'),
                      ),
                    ),
                    icon: const Icon(Icons.bookmark_border_rounded),
                  ),
                  IconButton(
                    onPressed: widget.onNavigateToCart,
                    icon: const Icon(Icons.shopping_bag_outlined),
                  ),
                ],
              ),
            ),
            _StepHeader(currentStep: state.currentStep, titles: stepTitles),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 130),
                child: _buildStepContent(),
              ),
            ),
          ],
        ),
        bottomSheet: _BottomSummaryBar(
          state: state,
          total: grandTotal,
          onNext: nextStep,
          nextTitle: state.currentStep == 4 ? 'أضف للعربة' : 'التالي',
        ),
      ),
    );
  }

  Widget _buildStepContent() {
    switch (state.currentStep) {
      case 0:
        return _buildBoxStep();
      case 1:
        return _buildProductsStep();
      case 2:
        return _buildGreetingStep();
      case 3:
        return _buildWrapStep();
      default:
        return _buildReviewStep();
    }
  }

  Widget _buildBoxStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('اختَر البوكس المناسب', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        const Text('ابدأ باختيار البوكس الذي يناسب عدد الهدايا وطبيعة المناسبة.'),
        const SizedBox(height: 18),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF7F1),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.line),
          ),
          child: Row(
            children: [
              const Icon(Icons.lightbulb_outline_rounded, color: AppColors.warning),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  state.selectedProducts.length >= 4
                      ? 'أنت قريب من بوكس كبير. راجع السعة علشان الهدية تطلع بشكل ممتاز.'
                      : 'نصيحة: ابدأ بالبوكس الكبير إذا كنت تخطط لإضافة أكثر من 4 عناصر.',
                  style: const TextStyle(height: 1.6),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: const [
            _StaticChip(label: 'الكل', active: true),
            _StaticChip(label: 'صغير'),
            _StaticChip(label: 'متوسط'),
            _StaticChip(label: 'كبير'),
            _StaticChip(label: 'فاخر'),
            _StaticChip(label: 'نسائي'),
          ],
        ),
        const SizedBox(height: 18),
        ...MockStoreService.boxes.map((box) {
          final selected = state.selectedBox?.id == box.id;
          return Card(
            margin: const EdgeInsets.only(bottom: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: BorderSide(
                color: selected ? AppColors.gold : AppColors.line,
                width: selected ? 1.4 : 1,
              ),
            ),
            child: InkWell(
              borderRadius: BorderRadius.circular(24),
              onTap: () => setState(() => state = state.copyWith(selectedBox: box)),
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Row(
                  children: [
                    Container(
                      width: 76,
                      height: 76,
                      decoration: BoxDecoration(
                        color: AppColors.beige,
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: Center(
                        child: Text(box.image, style: const TextStyle(fontSize: 34)),
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            box.name,
                            style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: 17,
                            ),
                          ),
                          const SizedBox(height: 6),
                          Text(
                            '${box.size} • ${box.capacity}',
                            style: const TextStyle(color: AppColors.textSecondary),
                          ),
                          const SizedBox(height: 10),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFFF4DE),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Text(
                              '${box.price.toStringAsFixed(0)} ج.م',
                              style: const TextStyle(
                                color: AppColors.mocha,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: selected ? AppColors.gold : AppColors.beige,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        selected ? Icons.check : Icons.add,
                        color: selected ? Colors.white : AppColors.mocha,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        }),
      ],
    );
  }

  Widget _buildProductsStep() {
    final products = filteredProducts;
    final selectedCount = state.selectedProducts.length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('اختَر الهدية', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        const Text('أضف العناصر التي تناسب ذوقك والمناسبة.'),
        const SizedBox(height: 16),
        TextField(
          controller: searchController,
          onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.search),
            hintText: 'ابحث عن هدية',
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 42,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: MockStoreService.giftCategories.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final cat = MockStoreService.giftCategories[index];
              final active = cat == currentCategory;
              return ChoiceChip(
                label: Text(cat),
                selected: active,
                onSelected: (_) => setState(() => currentCategory = cat),
                selectedColor: AppColors.mocha,
                backgroundColor: AppColors.beige,
                labelStyle: TextStyle(
                  color: active ? Colors.white : AppColors.mocha,
                  fontWeight: FontWeight.w700,
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.line),
          ),
          child: Row(
            children: [
              const Icon(Icons.auto_awesome_rounded, color: AppColors.gold),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'تم اختيار $selectedCount عنصر • ${state.selectedBox?.capacity ?? 'اختر البوكس لعرض السعة'}',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              Text(
                '${productsTotal.toStringAsFixed(0)} ج.م',
                style: const TextStyle(
                  color: AppColors.mocha,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        if (products.isEmpty)
          const _EmptyGiftState()
        else
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: products.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 0.62,
              mainAxisSpacing: 14,
              crossAxisSpacing: 14,
            ),
            itemBuilder: (context, index) {
              final product = products[index];
              final selected = state.selectedProducts.any((e) => e.id == product.id);
              return ProductCard(
                product: product,
                selected: selected,
                onTap: () => _openProduct(product),
                onAdd: () {
                  setState(() {
                    final next = [...state.selectedProducts];
                    if (selected) {
                      next.removeWhere((e) => e.id == product.id);
                    } else {
                      next.add(product);
                    }
                    state = state.copyWith(selectedProducts: next);
                  });
                },
              );
            },
          ),
      ],
    );
  }

  Widget _buildGreetingStep() {
    final templates = MockStoreService.messageTemplates[state.occasion] ?? const <String>[];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('أضف لمستك الخاصة', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        const Text('اختَر المناسبة وأضف كلمات التهنئة وبيانات الإهداء.'),
        const SizedBox(height: 18),
        const Text('نوع المناسبة', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: MockStoreService.occasions.map((occasion) {
            final active = state.occasion == occasion;
            return ChoiceChip(
              label: Text(occasion),
              selected: active,
              onSelected: (_) {
                setState(() {
                  state = state.copyWith(occasion: occasion);
                  selectedTemplate = '';
                });
              },
              selectedColor: AppColors.rose,
              backgroundColor: const Color(0xFFFFF7F1),
              labelStyle: TextStyle(
                color: active ? Colors.white : AppColors.mocha,
                fontWeight: FontWeight.w700,
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 18),
        const Text('رسائل جاهزة', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: templates.map((template) {
            final active = selectedTemplate == template;
            return GestureDetector(
              onTap: () {
                setState(() {
                  selectedTemplate = template;
                  messageController.text = template;
                  state = state.copyWith(message: template);
                });
              },
              child: Container(
                width: 160,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: active ? AppColors.mocha : AppColors.card,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: active ? AppColors.mocha : AppColors.line,
                  ),
                ),
                child: Text(
                  template,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: active ? Colors.white : AppColors.textPrimary,
                    fontWeight: FontWeight.w700,
                    height: 1.5,
                    fontSize: 12,
                  ),
                ),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 18),
        TextField(
          controller: messageController,
          maxLines: 4,
          onChanged: (value) => setState(() => state = state.copyWith(message: value)),
          decoration: const InputDecoration(hintText: 'اكتب رسالة التهنئة هنا'),
        ),
        const SizedBox(height: 14),
        TextField(
          controller: recipientController,
          onChanged: (value) => setState(() => state = state.copyWith(recipientName: value)),
          decoration: const InputDecoration(labelText: 'اسم المُرسَل إليه'),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: senderController,
          onChanged: (value) => setState(() => state = state.copyWith(senderName: value)),
          decoration: const InputDecoration(labelText: 'اسم المُرسِل'),
        ),
        const SizedBox(height: 18),
        Card(
          color: const Color(0xFFFFFBF5),
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Icon(Icons.credit_card_rounded, color: AppColors.gold),
                    SizedBox(width: 8),
                    Text(
                      'معاينة البطاقة',
                      style: TextStyle(
                        fontWeight: FontWeight.w800,
                        color: AppColors.mocha,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text('المناسبة: ${state.occasion}'),
                const SizedBox(height: 8),
                Text('إلى: ${recipientController.text.isEmpty ? 'اسم المستلم' : recipientController.text}'),
                const SizedBox(height: 8),
                Text(messageController.text.isEmpty ? 'رسالتك ستظهر هنا' : messageController.text),
                const SizedBox(height: 8),
                Text('من: ${senderController.text.isEmpty ? 'اسم المرسل' : senderController.text}'),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildWrapStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('اختَر التغليف', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        const Text('اجعل الهدية أكثر فخامة بتغليف يليق بالمناسبة.'),
        const SizedBox(height: 18),
        ...MockStoreService.wraps.map((wrap) {
          final selected = state.wrapOption?.id == wrap.id;
          return Card(
            margin: const EdgeInsets.only(bottom: 14),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(24),
              side: BorderSide(
                color: selected ? AppColors.gold : AppColors.line,
                width: selected ? 1.4 : 1,
              ),
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              leading: CircleAvatar(
                backgroundColor: AppColors.beige,
                child: Icon(
                  selected ? Icons.check : Icons.card_giftcard,
                  color: AppColors.mocha,
                ),
              ),
              title: Text(wrap.title, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(wrap.description),
              trailing: Text(
                '${wrap.price.toStringAsFixed(0)} ج.م',
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  color: AppColors.mocha,
                ),
              ),
              onTap: () => setState(() => state = state.copyWith(wrapOption: wrap)),
            ),
          );
        }),
        const SizedBox(height: 10),
        const Text('إضافات مميزة', style: TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: MockStoreService.addonPrices.entries.map((entry) {
            final active = selectedAddons.contains(entry.key);
            return FilterChip(
              label: Text('${entry.key} +${entry.value.toStringAsFixed(0)} ج.م'),
              selected: active,
              onSelected: (_) {
                setState(() {
                  if (active) {
                    selectedAddons.remove(entry.key);
                  } else {
                    selectedAddons.add(entry.key);
                  }
                });
              },
              selectedColor: AppColors.mocha,
              backgroundColor: AppColors.beige,
              labelStyle: TextStyle(
                color: active ? Colors.white : AppColors.mocha,
                fontWeight: FontWeight.w700,
              ),
              checkmarkColor: Colors.white,
            );
          }).toList(),
        ),
        const SizedBox(height: 18),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.line),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'معاينة التغليف',
                style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
              ),
              const SizedBox(height: 10),
              Text(state.wrapOption?.title ?? 'لم يتم اختيار نوع التغليف بعد'),
              const SizedBox(height: 8),
              Text(
                selectedAddons.isEmpty ? 'لا توجد إضافات حالياً' : selectedAddons.join(' • '),
                style: const TextStyle(color: AppColors.textSecondary),
              ),
              const SizedBox(height: 8),
              Text(
                'تكلفة الإضافات: ${addonsTotal.toStringAsFixed(0)} ج.م',
                style: const TextStyle(
                  color: AppColors.mocha,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildReviewStep() {
    final readyChecks = [
      {'label': 'تم اختيار بوكس', 'done': state.selectedBox != null},
      {'label': 'تم اختيار هدايا', 'done': state.selectedProducts.isNotEmpty},
      {
        'label': 'بطاقة التهنئة جاهزة',
        'done': recipientController.text.trim().isNotEmpty && messageController.text.trim().isNotEmpty,
      },
      {'label': 'التغليف جاهز', 'done': state.wrapOption != null},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('راجع هديتك', style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 8),
        const Text('دلوقتي أنت في آخر خطوة قبل إضافة الطلب للعربة والانتقال لمرحلة الشراء.'),
        const SizedBox(height: 18),
        Card(
          color: const Color(0xFFFFF7F1),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'جاهزية الطلب',
                  style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
                ),
                const SizedBox(height: 12),
                ...readyChecks.map(
                  (item) => _ReadyCheck(
                    label: item['label'] as String,
                    done: item['done'] as bool,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        _SummaryCard(
          title: 'البوكس',
          content: state.selectedBox == null
              ? 'لم يتم اختيار بوكس بعد'
              : '${state.selectedBox!.name} • ${state.selectedBox!.capacity} • ${state.selectedBox!.price.toStringAsFixed(0)} ج.م',
        ),
        _SummaryCard(
          title: 'الهدايا المختارة',
          content: state.selectedProducts.isEmpty
              ? 'لم يتم اختيار منتجات بعد'
              : state.selectedProducts.map((e) => '• ${e.title} — ${e.price.toStringAsFixed(0)} ج.م').join('\n'),
        ),
        _SummaryCard(
          title: 'التهنئة',
          content:
              'المناسبة: ${state.occasion}\nإلى: ${state.recipientName.isEmpty ? '-' : state.recipientName}\nمن: ${state.senderName.isEmpty ? '-' : state.senderName}\nالرسالة: ${state.message.isEmpty ? 'لا توجد رسالة' : state.message}',
        ),
        _SummaryCard(
          title: 'التغليف',
          content: state.wrapOption == null
              ? 'لم يتم اختيار تغليف'
              : '${state.wrapOption!.title} • ${state.wrapOption!.price.toStringAsFixed(0)} ج.م\nالإضافات: ${selectedAddons.isEmpty ? 'لا توجد إضافات' : selectedAddons.join(' • ')}',
        ),
        Card(
          color: AppColors.mocha,
          child: Padding(
            padding: const EdgeInsets.all(18),
            child: Column(
              children: [
                _PriceRow(label: 'سعر البوكس', value: state.selectedBox?.price ?? 0),
                _PriceRow(label: 'سعر المنتجات', value: productsTotal),
                _PriceRow(label: 'التغليف', value: state.wrapOption?.price ?? 0),
                _PriceRow(label: 'الإضافات', value: addonsTotal),
                const Divider(color: Color(0x33FFFFFF), height: 24),
                Row(
                  children: [
                    const Expanded(
                      child: Text(
                        'الإجمالي المتوقع',
                        style: TextStyle(
                          color: Color(0xFFF7E7CF),
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                    Text(
                      '${grandTotal.toStringAsFixed(0)} ج.م',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: AppColors.line),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text(
                'ماذا يحدث بعد الضغط على أضف للعربة؟',
                style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
              ),
              SizedBox(height: 10),
              Text('1) هيتحول البوكس المخصص لعنصر واحد واضح داخل العربة.'),
              SizedBox(height: 6),
              Text('2) هتراجع بيانات العميل والشحن والدفع.'),
              SizedBox(height: 6),
              Text('3) لو Shopify جاهز هيتم فتح الـ Checkout الحقيقي، ولو لأ هتقدر تختبر طلب تجريبي كامل.'),
            ],
          ),
        ),
      ],
    );
  }
}

class _StepHeader extends StatelessWidget {
  final int currentStep;
  final List<String> titles;

  const _StepHeader({required this.currentStep, required this.titles});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: List.generate(titles.length, (index) {
          final active = index == currentStep;
          final done = index < currentStep;
          return Expanded(
            child: Column(
              children: [
                Row(
                  children: [
                    if (index != 0)
                      Expanded(
                        child: Container(
                          height: 2,
                          color: done ? AppColors.gold : AppColors.line,
                        ),
                      ),
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: active ? AppColors.mocha : (done ? AppColors.gold : AppColors.beige),
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Icon(
                          done ? Icons.check : Icons.circle,
                          size: done ? 16 : 8,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    if (index != titles.length - 1)
                      Expanded(
                        child: Container(
                          height: 2,
                          color: done ? AppColors.gold : AppColors.line,
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  titles[index],
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: active ? FontWeight.w800 : FontWeight.w600,
                    color: active ? AppColors.mocha : AppColors.textMuted,
                  ),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}

class _BottomSummaryBar extends StatelessWidget {
  final GiftBuilderState state;
  final double total;
  final VoidCallback onNext;
  final String nextTitle;

  const _BottomSummaryBar({
    required this.state,
    required this.total,
    required this.onNext,
    required this.nextTitle,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 14, 18, 24),
      decoration: const BoxDecoration(
        color: AppColors.card,
        border: Border(top: BorderSide(color: AppColors.line)),
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    state.selectedBox?.name ?? 'لم يتم اختيار بوكس',
                    style: const TextStyle(
                      color: AppColors.mocha,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${state.selectedProducts.length} عناصر • ${total.toStringAsFixed(0)} ج.م',
                    style: const TextStyle(
                      color: AppColors.textMuted,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ElevatedButton(
                onPressed: onNext,
                child: Text(nextTitle),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StaticChip extends StatelessWidget {
  final String label;
  final bool active;

  const _StaticChip({required this.label, this.active = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: active ? AppColors.mocha : AppColors.beige,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: active ? Colors.white : AppColors.mocha,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  final String title;
  final String content;

  const _SummaryCard({required this.title, required this.content});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                color: AppColors.mocha,
              ),
            ),
            const SizedBox(height: 10),
            Text(content, style: const TextStyle(height: 1.7)),
          ],
        ),
      ),
    );
  }
}

class _PriceRow extends StatelessWidget {
  final String label;
  final double value;

  const _PriceRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              label,
              style: const TextStyle(color: Color(0xFFD8C2A6)),
            ),
          ),
          Text(
            '${value.toStringAsFixed(0)} ج.م',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}

class _ReadyCheck extends StatelessWidget {
  final String label;
  final bool done;

  const _ReadyCheck({required this.label, required this.done});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Row(
        children: [
          Icon(
            done ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
            color: done ? AppColors.olive : AppColors.textMuted,
            size: 20,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: TextStyle(
                color: done ? AppColors.textPrimary : AppColors.textMuted,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyGiftState extends StatelessWidget {
  const _EmptyGiftState();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppColors.line),
      ),
      child: const Column(
        children: [
          Icon(Icons.inventory_2_outlined, size: 40, color: AppColors.textMuted),
          SizedBox(height: 10),
          Text(
            'لا توجد نتائج حالياً',
            style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.mocha),
          ),
          SizedBox(height: 8),
          Text('جرّب تغيير التصنيف أو كتابة اسم منتج مختلف.'),
        ],
      ),
    );
  }
}
