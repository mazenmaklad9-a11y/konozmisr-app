import 'package:flutter/material.dart';

import '../../../core/config/app_config.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/controllers/app_cart_controller.dart';
import '../../../data/models/product.dart';
import '../../../data/repositories/store_repository.dart';
import '../../../data/services/mock_store_service.dart';
import '../../widgets/product_card.dart';
import '../product/product_detail_screen.dart';

enum _CatalogMode { all, liveReady, offers }

class CatalogScreen extends StatefulWidget {
  const CatalogScreen({super.key});

  @override
  State<CatalogScreen> createState() => _CatalogScreenState();
}

class _CatalogScreenState extends State<CatalogScreen> {
  final StoreRepository _repository = StoreRepository();
  String selectedCategory = MockStoreService.storeCategories.first;
  final searchController = TextEditingController();
  late Future<List<Product>> _future;
  _CatalogMode mode = _CatalogMode.all;

  @override
  void initState() {
    super.initState();
    _future = _repository.getCatalogProducts();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  void _reload() {
    setState(() => _future = _repository.getCatalogProducts());
  }

  List<Product> _filterProducts(List<Product> source) {
    final query = searchController.text.trim();

    return source.where((product) {
      final matchesCategory = selectedCategory == 'الكل' || product.category == selectedCategory;
      final matchesSearch = query.isEmpty ||
          product.title.contains(query) ||
          product.description.contains(query) ||
          product.category.contains(query);
      final matchesMode = switch (mode) {
        _CatalogMode.all => true,
        _CatalogMode.liveReady => product.variantId != null,
        _CatalogMode.offers => product.isSale,
      };
      return matchesCategory && matchesSearch && matchesMode;
    }).toList();
  }

  void _openProduct(Product product) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProductDetailScreen(product: product)),
    );
  }

  void _addToCart(Product product) {
    AppCartController.instance.addProduct(product);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: AppColors.olive,
        content: Text('تمت إضافة ${product.title} إلى العربة'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الأقسام والمنتجات'),
          actions: [
            IconButton(onPressed: _reload, icon: const Icon(Icons.refresh_rounded)),
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 8),
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppConfig.isLiveModeRequested ? const Color(0xFFEAF4E4) : const Color(0xFFFFF7F1),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    AppConfig.isLiveModeRequested ? 'Live' : 'Test',
                    style: TextStyle(
                      color: AppConfig.isLiveModeRequested ? AppColors.olive : AppColors.warning,
                      fontWeight: FontWeight.w800,
                      fontSize: 12,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
        body: FutureBuilder<List<Product>>(
          future: _future,
          builder: (context, snapshot) {
            final source = snapshot.data ?? const <Product>[];
            final products = _filterProducts(source);
            final loading = snapshot.connectionState == ConnectionState.waiting;
            final liveReadyCount = source.where((product) => product.variantId != null).length;
            final offersCount = source.where((product) => product.isSale).length;

            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 14),
                  child: Column(
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppColors.card,
                          borderRadius: BorderRadius.circular(22),
                          border: Border.all(color: AppColors.line),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'مركز التحويل السريع',
                              style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              AppConfig.isLiveModeRequested
                                  ? 'أنت الآن قريب جدًا من إطلاق حي يرفع المبيعات ويخلي رحلة الشراء أسرع.'
                                  : 'وضع الاختبار شغال بكفاءة. جرّب الفلاتر وشوف المنتجات الجاهزة للربط أولاً.',
                              style: const TextStyle(height: 1.7, color: AppColors.textSecondary),
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                _QuickMetric(label: 'كل المنتجات', value: '${source.length}'),
                                _QuickMetric(label: 'Live-ready', value: '$liveReadyCount'),
                                _QuickMetric(label: 'العروض', value: '$offersCount'),
                              ],
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 14),
                      TextField(
                        controller: searchController,
                        onChanged: (_) => setState(() {}),
                        decoration: const InputDecoration(
                          prefixIcon: Icon(Icons.search_rounded),
                          hintText: 'ابحث عن بوكس، طقم قهوة أو هدية',
                        ),
                      ),
                      const SizedBox(height: 14),
                      SizedBox(
                        height: 42,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: MockStoreService.storeCategories.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 8),
                          itemBuilder: (context, index) {
                            final category = MockStoreService.storeCategories[index];
                            final active = category == selectedCategory;
                            return ChoiceChip(
                              label: Text(category),
                              selected: active,
                              onSelected: (_) => setState(() => selectedCategory = category),
                              selectedColor: AppColors.mocha,
                              backgroundColor: AppColors.beige,
                              labelStyle: TextStyle(
                                color: active ? Colors.white : AppColors.mocha,
                                fontWeight: FontWeight.w700,
                              ),
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(
                            child: _ModeChip(
                              label: 'الكل',
                              active: mode == _CatalogMode.all,
                              onTap: () => setState(() => mode = _CatalogMode.all),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _ModeChip(
                              label: 'جاهز للدفع',
                              active: mode == _CatalogMode.liveReady,
                              onTap: () => setState(() => mode = _CatalogMode.liveReady),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: _ModeChip(
                              label: 'العروض',
                              active: mode == _CatalogMode.offers,
                              onTap: () => setState(() => mode = _CatalogMode.offers),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Text(
                            loading ? 'جاري التحميل...' : '${products.length} منتج',
                            style: const TextStyle(
                              color: AppColors.mocha,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const Spacer(),
                          Text(
                            AppConfig.dataModeLabel,
                            style: const TextStyle(color: AppColors.textMuted),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: loading
                      ? const _CatalogLoadingState()
                      : products.isEmpty
                          ? const _EmptyCatalogState()
                          : GridView.builder(
                              padding: const EdgeInsets.fromLTRB(20, 0, 20, 110),
                              itemCount: products.length,
                              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                childAspectRatio: 0.62,
                                mainAxisSpacing: 14,
                                crossAxisSpacing: 14,
                              ),
                              itemBuilder: (context, index) {
                                final product = products[index];
                                return ProductCard(
                                  product: product,
                                  onTap: () => _openProduct(product),
                                  onAdd: () => _addToCart(product),
                                  selected: AppCartController.instance.contains(product.id),
                                );
                              },
                            ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _ModeChip extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _ModeChip({required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(vertical: 11),
        decoration: BoxDecoration(
          color: active ? AppColors.mocha : AppColors.beige,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: active ? Colors.white : AppColors.mocha,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }
}

class _QuickMetric extends StatelessWidget {
  final String label;
  final String value;

  const _QuickMetric({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.beige,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(value, style: const TextStyle(fontWeight: FontWeight.w900, color: AppColors.mocha)),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.textSecondary)),
        ],
      ),
    );
  }
}

class _CatalogLoadingState extends StatelessWidget {
  const _CatalogLoadingState();

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 110),
      itemCount: 6,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.62,
        mainAxisSpacing: 14,
        crossAxisSpacing: 14,
      ),
      itemBuilder: (context, index) => Container(
        decoration: BoxDecoration(
          color: AppColors.beige,
          borderRadius: BorderRadius.circular(24),
        ),
      ),
    );
  }
}

class _EmptyCatalogState extends StatelessWidget {
  const _EmptyCatalogState();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 90,
              height: 90,
              decoration: BoxDecoration(
                color: AppColors.beige,
                borderRadius: BorderRadius.circular(28),
              ),
              child: const Icon(Icons.search_off_rounded, color: AppColors.mocha, size: 42),
            ),
            const SizedBox(height: 16),
            const Text(
              'لا توجد نتائج حالياً',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w800,
                color: AppColors.mocha,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'جرّب تغيير القسم أو الفلتر أو كتابة كلمة بحث مختلفة لإظهار المنتجات المناسبة.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.textSecondary, height: 1.6),
            ),
          ],
        ),
      ),
    );
  }
}
