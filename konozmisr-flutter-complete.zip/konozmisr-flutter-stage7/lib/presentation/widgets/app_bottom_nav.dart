import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class AppBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const AppBottomNav({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return NavigationBar(
      selectedIndex: currentIndex,
      onDestinationSelected: onTap,
      backgroundColor: AppColors.card,
      indicatorColor: AppColors.beige,
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
        NavigationDestination(icon: Icon(Icons.card_giftcard), label: 'اختر هديتك'),
        NavigationDestination(icon: Icon(Icons.grid_view_rounded), label: 'الأقسام'),
        NavigationDestination(icon: Icon(Icons.shopping_bag_outlined), label: 'العربة'),
        NavigationDestination(icon: Icon(Icons.person_outline), label: 'الحساب'),
      ],
    );
  }
}
