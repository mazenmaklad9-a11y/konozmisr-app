import 'package:flutter/material.dart';

import '../../core/theme/app_theme.dart';
import '../../data/models/product.dart';

class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback? onAdd;
  final VoidCallback? onTap;
  final bool selected;
  final String actionLabel;

  const ProductCard({
    super.key,
    required this.product,
    this.onAdd,
    this.onTap,
    this.selected = false,
    this.actionLabel = 'أضف',
  });

  bool get _hasNetworkImage => product.image.startsWith('http');

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
          side: BorderSide(
            color: selected ? AppColors.gold : AppColors.line,
            width: selected ? 1.4 : 1,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        if (product.badge != null)
                          _ProductBadge(
                            label: product.badge!,
                            color: const Color(0xFFFFF4DE),
                            textColor: AppColors.mocha,
                          ),
                        if (product.isSale)
                          const _ProductBadge(
                            label: 'خصم',
                            color: AppColors.rose,
                            textColor: Colors.white,
                          ),
                        if (product.variantId != null)
                          const _ProductBadge(
                            label: 'جاهز للدفع المباشر',
                            color: AppColors.teal,
                            textColor: Colors.white,
                          ),
                        if (product.isCustomGift)
                          const _ProductBadge(
                            label: 'طلب مخصص',
                            color: AppColors.olive,
                            textColor: Colors.white,
                          ),
                      ],
                    ),
                  ),
                  const Icon(Icons.favorite_border_rounded, color: AppColors.textMuted, size: 18),
                ],
              ),
              const SizedBox(height: 16),
              Expanded(
                child: Center(
                  child: _hasNetworkImage
                      ? ClipRRect(
                          borderRadius: BorderRadius.circular(18),
                          child: Image.network(
                            product.image,
                            fit: BoxFit.cover,
                            width: double.infinity,
                            errorBuilder: (_, __, ___) => const Text('🛍️', style: TextStyle(fontSize: 48)),
                          ),
                        )
                      : Text(product.image, style: const TextStyle(fontSize: 48)),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                product.category,
                style: const TextStyle(
                  color: AppColors.textMuted,
                  fontWeight: FontWeight.w700,
                  fontSize: 12,
                ),
              ),
              const SizedBox(height: 6),
              Text(
                product.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontWeight: FontWeight.w800,
                  color: AppColors.textPrimary,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                product.compatibility,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppColors.teal,
                  fontSize: 12,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Icon(
                    product.variantId != null ? Icons.cloud_done_rounded : Icons.science_outlined,
                    size: 14,
                    color: product.variantId != null ? AppColors.olive : AppColors.warning,
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      product.variantId != null ? 'منتج Live-ready' : 'منتج تجريبي للاختبار',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: product.variantId != null ? AppColors.olive : AppColors.warning,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
              const Spacer(),
              Row(
                children: [
                  Text(
                    '${product.price.toStringAsFixed(0)} ج.م',
                    style: const TextStyle(
                      color: AppColors.mocha,
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(width: 8),
                  if (product.oldPrice != null)
                    Expanded(
                      child: Text(
                        '${product.oldPrice!.toStringAsFixed(0)}',
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          decoration: TextDecoration.lineThrough,
                          color: AppColors.textMuted,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: onTap,
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 42),
                        side: const BorderSide(color: AppColors.line),
                      ),
                      child: const Text('التفاصيل'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: onAdd,
                      style: ElevatedButton.styleFrom(
                        minimumSize: const Size(double.infinity, 42),
                        backgroundColor: selected ? AppColors.gold : AppColors.mocha,
                        foregroundColor: selected ? AppColors.mocha : Colors.white,
                      ),
                      child: Text(selected ? 'تمت الإضافة' : actionLabel),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProductBadge extends StatelessWidget {
  final String label;
  final Color color;
  final Color textColor;

  const _ProductBadge({
    required this.label,
    required this.color,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: textColor,
          fontWeight: FontWeight.w800,
          fontSize: 11,
        ),
      ),
    );
  }
}
