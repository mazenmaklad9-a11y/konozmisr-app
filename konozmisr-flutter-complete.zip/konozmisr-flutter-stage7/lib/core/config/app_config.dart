class AppConfig {
  static const storeUrl = 'https://konozmisr.com';
  static const storefrontApiVersion = '2025-01';

  /// Important:
  /// - Use ONLY the PUBLIC Storefront token in the mobile app.
  /// - Never place any private/admin token inside Flutter source.
  static const publicStorefrontToken = 'PUT_PUBLIC_STOREFRONT_TOKEN_HERE';

  /// If false and a valid public token exists, the app will try live Shopify data.
  static const enableMockData = false;

  /// Deferred until final payment phase.
  static const paymobEnabled = false;

  /// Play release readiness references.
  static const requiredAndroidTargetApi = 35;
  static const preferredReleaseArtifact = 'AAB';
  static const requiresAppBundle = true;

  static bool get hasValidStorefrontToken =>
      publicStorefrontToken.isNotEmpty &&
      publicStorefrontToken != 'PUT_PUBLIC_STOREFRONT_TOKEN_HERE';

  static bool get isLiveModeRequested => hasValidStorefrontToken && !enableMockData;

  static String get dataModeLabel => isLiveModeRequested ? 'Live Shopify' : 'Mock / Test Mode';

  static String get storefrontGraphQLEndpoint =>
      '$storeUrl/api/$storefrontApiVersion/graphql.json';
}
